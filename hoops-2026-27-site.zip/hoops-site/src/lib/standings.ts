import type { Conference, StandingsState, Team, TeamRecord } from '../types';

export const AP_MAX = 25;

export const emptyRecord = (): TeamRecord => ({
  confW: null,
  confL: null,
  ovW: null,
  ovL: null,
  homeW: null,
  homeL: null,
  awayW: null,
  awayL: null,
  ap: null,
});

/** Winning percentage as a number, or null when no games have been entered. */
export function pct(w: number | null, l: number | null): number | null {
  const ww = w ?? 0;
  const ll = l ?? 0;
  return ww + ll > 0 ? ww / (ww + ll) : null;
}

export function fmtPct(p: number | null): string {
  if (p === null) return '—';
  return p >= 1 ? '1.000' : p.toFixed(3).replace(/^0/, '');
}

export const hasConfGames = (r: TeamRecord) => (r.confW ?? 0) + (r.confL ?? 0) > 0;

export function initialState(conferences: Conference[]): StandingsState {
  const order: Record<string, string[]> = {};
  const records: Record<string, TeamRecord> = {};
  for (const c of conferences) {
    // ACC keeps the CSV order; every other conference starts alphabetical.
    const teams = c.id === 'acc' ? c.teams : [...c.teams].sort((a, b) => a.name.localeCompare(b.name));
    order[c.id] = teams.map((t) => t.key);
    for (const t of c.teams) records[t.key] = emptyRecord();
  }
  return { version: 1, autoSort: true, order, records };
}

/** Make a loaded state match the current conference/team list (adds new teams, drops removed ones). */
export function reconcile(state: StandingsState, conferences: Conference[]): StandingsState {
  const base = initialState(conferences);
  const order: Record<string, string[]> = {};
  const records: Record<string, TeamRecord> = {};
  for (const c of conferences) {
    const valid = new Set(c.teams.map((t) => t.key));
    const saved = (state.order[c.id] ?? []).filter((k) => valid.has(k));
    const missing = base.order[c.id].filter((k) => !saved.includes(k));
    order[c.id] = [...saved, ...missing];
    for (const t of c.teams) records[t.key] = { ...emptyRecord(), ...(state.records[t.key] ?? {}) };
  }
  // AP ranks are national: drop any duplicate that slipped in (keep the first team seen).
  const seen = new Set<number>();
  for (const c of conferences) {
    for (const k of order[c.id]) {
      const ap = records[k].ap;
      if (ap === null) continue;
      if (ap < 1 || ap > AP_MAX || seen.has(ap)) records[k].ap = null;
      else seen.add(ap);
    }
  }
  return { version: 1, autoSort: state.autoSort ?? true, order, records };
}

/**
 * Sort a conference by conference winning percentage, highest first.
 * - Teams with conference games entered come first, ordered by PCT (descending).
 * - Ties keep the order they had before (stable sort), so manual ordering is respected for ties.
 * - Teams with no conference games entered follow, in their existing order.
 */
export function sortByConfPct(order: string[], records: Record<string, TeamRecord>): string[] {
  const indexed = order.map((key, i) => ({ key, i, r: records[key] }));
  const entered = indexed.filter((x) => hasConfGames(x.r));
  const blank = indexed.filter((x) => !hasConfGames(x.r));
  entered.sort((a, b) => {
    const pa = pct(a.r.confW, a.r.confL)!;
    const pb = pct(b.r.confW, b.r.confL)!;
    return pb - pa || a.i - b.i;
  });
  return [...entered, ...blank].map((x) => x.key);
}

/** Games behind the leader, by conference record. "-" for the leader and for teams with no games. */
export function computeGB(order: string[], records: Record<string, TeamRecord>): Record<string, string> {
  const diffs = order
    .filter((k) => hasConfGames(records[k]))
    .map((k) => (records[k].confW ?? 0) - (records[k].confL ?? 0));
  const best = diffs.length ? Math.max(...diffs) : 0;
  const out: Record<string, string> = {};
  for (const k of order) {
    const r = records[k];
    if (!hasConfGames(r)) {
      out[k] = '-';
      continue;
    }
    const gb = (best - ((r.confW ?? 0) - (r.confL ?? 0))) / 2;
    out[k] = gb === 0 ? '-' : gb.toFixed(1).replace(/\.0$/, '');
  }
  return out;
}

/** Returns an error message when the record is not allowed, otherwise null. */
export function validateConfRecord(conf: Conference, w: number | null, l: number | null): string | null {
  for (const [label, v] of [['wins', w], ['losses', l]] as const) {
    if (v !== null && (!Number.isInteger(v) || v < 0)) return `Conference ${label} must be a whole number of 0 or more.`;
  }
  const total = (w ?? 0) + (l ?? 0);
  if (total > conf.maxConfGames) {
    return `${conf.name} teams play at most ${conf.maxConfGames} conference games. ${w ?? 0}-${l ?? 0} is ${total} games, so this record was not saved.`;
  }
  return null;
}

export function validateWholeNumber(label: string, v: number | null): string | null {
  if (v !== null && (!Number.isInteger(v) || v < 0)) return `${label} must be a whole number of 0 or more.`;
  return null;
}

/** rank -> team key for every ranked team across all conferences (the AP poll is national). */
export function apOwners(state: StandingsState): Record<number, string> {
  const owners: Record<number, string> = {};
  for (const [key, r] of Object.entries(state.records)) if (r.ap !== null) owners[r.ap] = key;
  return owners;
}

/** Assign an AP rank. A rank held by a different team is rejected. */
export function setAp(
  state: StandingsState,
  teamKey: string,
  rank: number | null,
  teamByKey: Record<string, Team>,
): { state: StandingsState; error?: string } {
  if (rank !== null) {
    if (!Number.isInteger(rank) || rank < 1 || rank > AP_MAX) return { state, error: `AP rank must be 1-${AP_MAX}.` };
    const owner = apOwners(state)[rank];
    if (owner && owner !== teamKey) {
      return { state, error: `AP #${rank} is already taken by ${teamByKey[owner]?.short ?? owner}.` };
    }
  }
  return {
    state: { ...state, records: { ...state.records, [teamKey]: { ...state.records[teamKey], ap: rank } } },
  };
}

export function moveItem<T>(arr: T[], from: number, to: number): T[] {
  if (from === to || from < 0 || to < 0 || from >= arr.length || to >= arr.length) return arr;
  const copy = arr.slice();
  const [item] = copy.splice(from, 1);
  copy.splice(to, 0, item);
  return copy;
}

export const fmtPair = (w: number | null, l: number | null) => (w === null && l === null ? '—' : `${w ?? 0}-${l ?? 0}`);
