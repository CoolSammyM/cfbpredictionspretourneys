import type { Conference, Team, Verification } from '../types';

/**
 * 2026-27 NCAA Division I men's basketball conferences.
 *
 * VERIFICATION LEVELS (shown in the UI as a badge on each conference):
 *  - csv        : order/members come from the user's pickem-standings-acc.csv
 *  - sourced    : membership checked against a 2026-27 realignment source
 *                 (FOX Sports realignment explainer, Nov 2 2026; Pac-12 announcements)
 *  - screenshot : membership copied from the user's reference screenshot
 *  - unverified : listed from general knowledge; NOT checked against a 2026-27 source.
 *                 Please confirm before relying on it.
 *
 * ESPN ids: only given where known with high confidence. `npm run verify-ids` checks
 * every id against ESPN's own team list and `npm run resolve-ids` fills the rest.
 * A team with no id shows a neutral fallback logo, never initials.
 */

export const slug = (s: string) =>
  s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/&/g, 'and')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');

export const T = (name: string, espnId: number | null = null, short?: string): Team => ({
  key: slug(name),
  name,
  short: short ?? name,
  espnId,
});

const S = (...names: string[]): Team[] => names.map((n) => T(n));

const conf = (
  id: string,
  name: string,
  maxConfGames: number,
  teams: Team[],
  verification: Verification,
  opts: { power?: boolean; note?: string } = {},
): Conference => ({
  id,
  name,
  maxConfGames,
  teams,
  verification,
  power: !!opts.power,
  note: opts.note,
});

// ACC — same order as pickem-standings-acc.csv (RK 1..18)
const ACC = [
  T('Boston College Eagles', 103, 'Boston College'),
  T('California Golden Bears', 25, 'California'),
  T('Clemson Tigers', 228, 'Clemson'),
  T('Duke Blue Devils', 150, 'Duke'),
  T('Florida State Seminoles', 52, 'Florida State'),
  T('Georgia Tech Yellow Jackets', 59, 'Georgia Tech'),
  T('Louisville Cardinals', 97, 'Louisville'),
  T('Miami Hurricanes', 2390, 'Miami'),
  T('NC State Wolfpack', 152, 'NC State'),
  T('North Carolina Tar Heels', 153, 'North Carolina'),
  T('Notre Dame Fighting Irish', 87, 'Notre Dame'),
  T('Pittsburgh Panthers', 221, 'Pitt'),
  T('SMU Mustangs', 2567, 'SMU'),
  T('Stanford Cardinal', 24, 'Stanford'),
  T('Syracuse Orange', 183, 'Syracuse'),
  T('Virginia Cavaliers', 258, 'Virginia'),
  T('Virginia Tech Hokies', 259, 'Virginia Tech'),
  T('Wake Forest Demon Deacons', 154, 'Wake Forest'),
];

export const CONFERENCES: Conference[] = [
  conf('america-east', 'America East', 16, [
    T('UMass Lowell River Hawks', 2349, 'UMass Lowell'),
    T('Binghamton Bearcats', null, 'Binghamton'),
    T('New Hampshire Wildcats', 160, 'New Hampshire'),
    T('UAlbany Great Danes', null, 'UAlbany'),
    T('UMBC Retrievers', null, 'UMBC'),
    T('Vermont Catamounts', null, 'Vermont'),
    T('Bryant Bulldogs', null, 'Bryant'),
    T('Maine Black Bears', null, 'Maine'),
    T('NJIT Highlanders', 2885, 'NJIT'),
  ], 'screenshot', { note: 'Members copied from the reference screenshot you supplied.' }),

  conf('american', 'American', 18, S(
    'Charlotte', 'East Carolina', 'Florida Atlantic', 'Memphis', 'North Texas', 'Rice',
    'South Florida', 'Temple', 'Tulane', 'Tulsa', 'UAB', 'UTSA', 'Wichita State',
  ), 'unverified', { note: 'Wichita State, Florida Atlantic and Memphis appear in your screenshot; the rest is from general knowledge.' }),

  conf('atlantic-10', 'Atlantic 10', 18, S(
    'Davidson', 'Dayton', 'Duquesne', 'Fordham', 'George Mason', 'George Washington',
    'La Salle', 'Loyola Chicago', 'Rhode Island', 'Richmond', "Saint Joseph's",
    'Saint Louis', 'St. Bonaventure', 'UMass', 'VCU',
  ), 'unverified'),

  conf('acc', 'ACC', 18, ACC, 'csv', { power: true, note: 'Teams and starting order from pickem-standings-acc.csv.' }),

  conf('asun', 'ASUN', 14, S(
    'Bellarmine', 'Florida Gulf Coast', 'Jacksonville', 'Lipscomb', 'North Florida', 'Queens', 'Stetson',
  ), 'unverified', { note: 'FOX reports Austin Peay, Central Arkansas, Eastern Kentucky, North Alabama and West Georgia left. Remaining list not confirmed against a 2026-27 source.' }),

  conf('big-12', 'Big 12', 18, [
    T('Arizona', 12), T('Arizona State', 9), T('Baylor', 239), T('BYU', 252), T('Cincinnati', 2132),
    T('Colorado', 38), T('Houston', 248), T('Iowa State', 66), T('Kansas', 2305), T('Kansas State', 2306),
    T('Oklahoma State', 197), T('TCU', 2628), T('Texas Tech', 2641), T('UCF', 2116), T('Utah', 254),
    T('West Virginia', 277),
  ], 'sourced', { power: true, note: 'FOX realignment explainer (Nov 2, 2026): the Power Four did not change for 2026-27.' }),

  conf('big-east', 'Big East', 20, [
    T('Butler', 2086), T('UConn', 41), T('Creighton', 156), T('DePaul', 305), T('Georgetown', 46),
    T('Marquette', 269), T('Providence', 2507), T('Seton Hall', 2550), T("St. John's", 2599),
    T('Villanova', 222), T('Xavier', 2752),
  ], 'unverified', { power: true, note: 'Not covered by the realignment source I found. Please confirm.' }),

  conf('big-sky', 'Big Sky', 20, S(
    'Eastern Washington', 'Idaho', 'Idaho State', 'Montana', 'Montana State', 'Northern Arizona',
    'Northern Colorado', 'Portland State', 'Weber State', 'Southern Utah', 'Utah Tech',
  ), 'sourced', { note: 'FOX: Southern Utah and Utah Tech joined; Sacramento State left.' }),

  conf('big-south', 'Big South', 16, S(
    'Charleston Southern', 'Gardner-Webb', 'High Point', 'Longwood', 'Presbyterian', 'Radford',
    'UNC Asheville', 'USC Upstate', 'Winthrop',
  ), 'unverified'),

  conf('big-ten', 'Big Ten', 20, [
    T('Illinois', 356), T('Indiana', 84), T('Iowa', 2294), T('Maryland', 120), T('Michigan', 130),
    T('Michigan State', 127), T('Minnesota', 135), T('Nebraska', 158), T('Northwestern', 77),
    T('Ohio State', 194), T('Oregon', 2483), T('Penn State', 213), T('Purdue', 2509), T('Rutgers', 164),
    T('UCLA', 26), T('USC', 30), T('Washington', 264), T('Wisconsin', 275),
  ], 'sourced', { power: true, note: 'FOX realignment explainer (Nov 2, 2026): the Power Four did not change for 2026-27.' }),

  conf('big-west', 'Big West', 20, S(
    'Cal Poly', 'Cal State Bakersfield', 'Cal State Fullerton', 'Cal State Northridge', 'Long Beach State',
    'UC Irvine', 'UC Riverside', 'UC Santa Barbara', 'UC San Diego', 'Sacramento State',
    'Cal Baptist', 'Utah Valley',
  ), 'sourced', { note: 'FOX: Sacramento State, Cal Baptist, Utah Valley joined; Hawaii and UC Davis left.' }),

  conf('caa', 'CAA', 18, S(
    'Campbell', 'Charleston', 'Drexel', 'Elon', 'Hampton', 'Hofstra', 'Monmouth', 'North Carolina A&T',
    'Northeastern', 'Stony Brook', 'Towson', 'UNC Wilmington', 'William & Mary',
  ), 'unverified'),

  conf('conference-usa', 'Conference USA', 18, S(
    'Delaware', 'FIU', 'Jacksonville State', 'Kennesaw State', 'Liberty', 'Middle Tennessee',
    'Missouri State', 'New Mexico State', 'Sam Houston', 'Western Kentucky',
  ), 'unverified', { note: 'FOX reports UTEP and Louisiana Tech left. Remaining list not confirmed against a 2026-27 source.' }),

  conf('horizon', 'Horizon League', 20, S(
    'Cleveland State', 'Detroit Mercy', 'Green Bay', 'IU Indy', 'Milwaukee', 'Northern Kentucky',
    'Oakland', 'Purdue Fort Wayne', 'Robert Morris', 'Wright State', 'Youngstown State', 'Northern Illinois',
  ), 'sourced', { note: 'FOX: Northern Illinois joined.' }),

  conf('ivy', 'Ivy League', 14, [
    T('Brown'), T('Columbia'), T('Cornell'), T('Dartmouth'), T('Harvard', 108), T('Penn'),
    T('Princeton'), T('Yale'),
  ], 'unverified'),

  conf('metro', 'Metro Conference (formerly MAAC)', 20, S(
    'Canisius', 'Fairfield', 'Iona', 'Manhattan', 'Marist', 'Merrimack', "Mount St. Mary's", 'Niagara',
    'Quinnipiac', 'Rider', 'Sacred Heart', "Saint Peter's", 'Siena',
  ), 'unverified', { note: 'Name per your request; roster not confirmed against a 2026-27 source.' }),

  conf('mac', 'MAC', 18, S(
    'Akron', 'Ball State', 'Bowling Green', 'Buffalo', 'Central Michigan', 'Eastern Michigan',
    'Kent State', 'Miami (OH)', 'Ohio', 'Toledo', 'Western Michigan',
  ), 'unverified', { note: 'FOX reports Northern Illinois left for the Horizon League.' }),

  conf('meac', 'MEAC', 14, S(
    'Coppin State', 'Delaware State', 'Howard', 'Maryland Eastern Shore', 'Morgan State', 'Norfolk State',
    'North Carolina Central', 'South Carolina State',
  ), 'unverified'),

  conf('missouri-valley', 'Missouri Valley', 20, S(
    'Belmont', 'Bradley', 'Drake', 'Evansville', 'Illinois State', 'Indiana State', 'Murray State',
    'Northern Iowa', 'Southern Illinois', 'UIC', 'Valparaiso',
  ), 'unverified'),

  conf('mountain-west', 'Mountain West', 20, S(
    'Air Force', 'Grand Canyon', 'Nevada', 'New Mexico', 'San Jose State', 'UNLV', 'Wyoming',
    'Hawaii', 'UC Davis', 'UTEP',
  ), 'sourced', { note: 'FOX: Hawaii, UC Davis, UTEP joined; Boise State, Colorado State, Fresno State, San Diego State, Utah State left.' }),

  conf('nec', 'NEC', 16, S(
    'Central Connecticut', 'Chicago State', 'Fairleigh Dickinson', 'LIU', 'Mercyhurst', 'Saint Francis',
    'Stonehill', 'Wagner',
  ), 'unverified'),

  conf('ovc', 'OVC', 18, S(
    'Eastern Illinois', 'Lindenwood', 'Morehead State', 'SIU Edwardsville', 'Southeast Missouri',
    'Southern Indiana', 'Tennessee State', 'UT Martin', 'Western Illinois',
  ), 'unverified', { note: 'FOX reports Tennessee Tech and Little Rock left. Remaining list not confirmed against a 2026-27 source.' }),

  conf('pac-12', 'Pac-12', 16, [
    T('Boise State', 68), T('Colorado State', 36), T('Fresno State', 278), T('Gonzaga', 2250),
    T('Oregon State', 204), T('San Diego State', 21), T('Texas State', 326), T('Utah State', 328),
    T('Washington State', 265),
  ], 'sourced', { power: true, note: 'Nine members per the Pac-12 relaunch announcement and FOX Sports.' }),

  conf('patriot', 'Patriot League', 18, S(
    'American', 'Army', 'Boston University', 'Bucknell', 'Colgate', 'Holy Cross', 'Lafayette', 'Lehigh',
    'Loyola Maryland', 'Navy',
  ), 'unverified'),

  conf('sec', 'SEC', 18, [
    T('Alabama', 333), T('Arkansas', 8), T('Auburn', 2), T('Florida', 57), T('Georgia', 61),
    T('Kentucky', 96), T('LSU', 99), T('Mississippi State', 344), T('Missouri', 142), T('Oklahoma', 201),
    T('Ole Miss', 145), T('South Carolina', 2579), T('Tennessee', 2633), T('Texas', 251),
    T('Texas A&M', 245), T('Vanderbilt', 238),
  ], 'sourced', { power: true, note: 'FOX realignment explainer (Nov 2, 2026): the Power Four did not change for 2026-27.' }),

  conf('southern', 'Southern', 18, S(
    'Chattanooga', 'The Citadel', 'East Tennessee State', 'Furman', 'Mercer', 'Samford', 'UNC Greensboro',
    'Western Carolina', 'Wofford', 'VMI', 'Tennessee Tech',
  ), 'sourced', { note: 'FOX: Tennessee Tech joined.' }),

  conf('southland', 'Southland', 20, S(
    'Houston Christian', 'Incarnate Word', 'Lamar', 'McNeese', 'New Orleans', 'Nicholls',
    'Northwestern State', 'Southeastern Louisiana', 'Stephen F. Austin', 'Texas A&M-Corpus Christi',
  ), 'unverified'),

  conf('swac', 'SWAC', 18, S(
    'Alabama A&M', 'Alabama State', 'Alcorn State', 'Arkansas-Pine Bluff', 'Bethune-Cookman',
    'Florida A&M', 'Grambling', 'Jackson State', 'Mississippi Valley State', 'Prairie View A&M',
    'Southern', 'Texas Southern',
  ), 'unverified'),

  conf('summit', 'Summit League', 16, S(
    'Kansas City', 'North Dakota', 'North Dakota State', 'Omaha', 'Oral Roberts', 'South Dakota',
    'South Dakota State', 'St. Thomas',
  ), 'unverified', { note: 'FOX reports Denver left for the WCC.' }),

  conf('sun-belt', 'Sun Belt', 18, S(
    'Appalachian State', 'Arkansas State', 'Coastal Carolina', 'Georgia Southern', 'Georgia State',
    'James Madison', 'Louisiana', 'Louisiana-Monroe', 'Louisiana Tech', 'Marshall', 'Old Dominion',
    'South Alabama', 'Southern Miss', 'Troy',
  ), 'sourced', { note: 'FOX: Louisiana Tech joined; Texas State left.' }),

  conf('uac', 'UAC', 18, S(
    'Abilene Christian', 'Tarleton State', 'UT Arlington', 'Austin Peay', 'Central Arkansas',
    'Eastern Kentucky', 'North Alabama', 'West Georgia', 'Little Rock',
  ), 'sourced', { note: 'FOX labels this league "Western Athletic Conference (United)". Members per FOX; please confirm the UAC name.' }),

  conf('wcc', 'WCC', 16, S(
    'Denver', 'Loyola Marymount', 'Pacific', 'Pepperdine', 'Portland', "Saint Mary's", 'San Francisco',
    'Santa Clara', 'Seattle',
  ), 'sourced', { note: 'FOX: Denver joined; Gonzaga left for the Pac-12.' }),
];

export const POWER_IDS = ['acc', 'big-ten', 'big-12', 'big-east', 'pac-12', 'sec'];
export const POWER_CONFERENCES = POWER_IDS.map((id) => CONFERENCES.find((c) => c.id === id)!);

export const ALL_TEAMS: Team[] = CONFERENCES.flatMap((c) => c.teams);
export const TEAM_BY_KEY: Record<string, Team> = Object.fromEntries(ALL_TEAMS.map((t) => [t.key, t]));
export const CONF_OF_TEAM: Record<string, string> = Object.fromEntries(
  CONFERENCES.flatMap((c) => c.teams.map((t) => [t.key, c.id])),
);
