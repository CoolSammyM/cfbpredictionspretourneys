import type { ReactNode } from 'react';

interface Props {
  title: string;
  tone?: 'warn' | 'info';
  onClose: () => void;
  children: ReactNode;
  actions?: ReactNode;
}

export default function Modal({ title, tone = 'info', onClose, children, actions }: Props) {
  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal modal-${tone}`} role="alertdialog" aria-modal="true" aria-label={title}>
        <h3>{title}</h3>
        <div className="modal-body">{children}</div>
        <div className="modal-actions">
          {actions ?? (
            <button className="btn btn-primary" autoFocus onClick={onClose}>
              OK
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
