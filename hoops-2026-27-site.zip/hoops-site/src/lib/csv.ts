import type { Conference, StandingsState, TeamRecord } from '../types';
import { AP_MAX, computeGB, fmtPair, fmtPct, pct, validateConfRecord } from './standings';

export const CSV_HEADERS = [
  'Conference', 'RK', 'Team', 'Conf W', 'Conf L', 'GB', 'Conf PCT',
  'Overall W', 'Overall L', 'Overall PCT', 'Home', 'Away', 'AP',
];

const esc = (v: string | number | null) => `"${String(v ?? '').replace(/"/g, '""')}"`;

const num = (v: number | null) => (v === null ? '' : v);

export function exportStandingsCsv(state: StandingsState, conferences: Conference[], onlyConfId?: string): string {
  const lines = [CSV_HEADERS.map(esc).join(',')];
  for (const c of conferences) {
    if (onlyConfId && c.id !== onlyConfId) continue;
    const order = state.order[c.id];
    const gb = computeGB(order, state.records);
    order.forEach((key, i) => {
      const r = state.records[key];
      const team = c.teams.find((t) => t.key === key)!;
      const hasHome = r.homeW !== null || r.homeL !== null;
      const hasAway = r.awayW !== null || r.awayL !== null;
      lines.push(
        [
          c.name, i + 1, team.name, num(r.confW), num(r.confL),
          r.confW === null && r.confL === null ? '' : gb[key],
          pct(r.confW, r.confL) === null ? '' : fmtPct(pct(r.confW, r.confL)),
          num(r.ovW), num(r.ovL),
          pct(r.ovW, r.ovL) === null ? '' : fmtPct(pct(r.ovW, r.ovL)),
          hasHome ? fmtPair(r.homeW, r.homeL) : '',
          hasAway ? fmtPair(r.awayW, r.awayL) : '',
          num(r.ap),
        ].map(esc).join(','),
      );
    });
  }
  return lines.join('\r\n') + '\r\n';
}

/** Small RFC-4180 style parser (quoted fields, escaped quotes, CRLF or LF). */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;
  const src = text.replace(/^﻿/, '');
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') { field += '"'; i++; } else quoted = false;
      } else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ',') { row.push(field); field = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && src[i + 1] === '\n') i++;
      row.push(field); field = '';
      if (row.some((f) => f.trim() !== '')) rows.push(row);
      row = [];
    } else field += ch;
  }
  row.push(field);
  if (row.some((f) => f.trim() !== '')) rows.push(row);
  return rows;
}

const toInt = (s: string | undefined): number | null => {
  const t = (s ?? '').trim();
  if (t === '' || t === '—' || t === '-') return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : NaN;
};

const parsePair = (s: string | undefined): [number | null, number | null] | 'bad' => {
  const t = (s ?? '').trim();
  if (t === '' || t === '—') return [null, null];
  const m = t.match(/^(\d+)\s*-\s*(\d+)$/);
  return m ? [Number(m[1]), Number(m[2])] : 'bad';
};

export interface ImportResult {
  state: StandingsState;
  applied: number;
  errors: string[];
}

/**
 * Import a standings CSV (same columns as the export / pickem-standings-acc.csv).
 * Rows are matched by conference name + team name. Invalid rows are skipped and reported;
 * nothing invalid is silently accepted. A legacy "USA" column is ignored.
 */
export function importStandingsCsv(text: string, current: StandingsState, conferences: Conference[]): ImportResult {
  const rows = parseCsv(text);
  const errors: string[] = [];
  if (rows.length < 2) return { state: current, applied: 0, errors: ['The file has no data rows.'] };
  const header = rows[0].map((h) => h.trim().toLowerCase());
  const col = (name: string) => header.indexOf(name.toLowerCase());
  const idx = {
    conf: col('Conference'), rk: col('RK'), team: col('Team'), cw: col('Conf W'), cl: col('Conf L'),
    ow: col('Overall W'), ol: col('Overall L'), home: col('Home'), away: col('Away'), ap: col('AP'),
  };
  if (idx.conf < 0 || idx.team < 0) {
    return { state: current, applied: 0, errors: ['Missing required "Conference" and "Team" columns.'] };
  }

  const records: Record<string, TeamRecord> = Object.fromEntries(
    Object.entries(current.records).map(([k, v]) => [k, { ...v }]),
  );
  const rankByConf: Record<string, { key: string; rk: number; line: number }[]> = {};
  const apTaken = new Map<number, string>();
  // AP ranks that stay on teams the file does not mention
  const touched = new Set<string>();
  let applied = 0;

  rows.slice(1).forEach((row, i) => {
    const line = i + 2;
    const cname = (row[idx.conf] ?? '').trim().toLowerCase();
    const tname = (row[idx.team] ?? '').trim().toLowerCase();
    const c = conferences.find((x) => x.name.toLowerCase() === cname || x.id === cname);
    const t = c?.teams.find((x) => x.name.toLowerCase() === tname || x.short.toLowerCase() === tname);
    if (!c || !t) { errors.push(`Line ${line}: "${row[idx.team]}" in "${row[idx.conf]}" was not found.`); return; }

    const cw = toInt(row[idx.cw]); const cl = toInt(row[idx.cl]);
    const ow = toInt(row[idx.ow]); const ol = toInt(row[idx.ol]);
    if ([cw, cl, ow, ol].some((v) => Number.isNaN(v))) { errors.push(`Line ${line}: ${t.name} has a non-numeric win/loss value.`); return; }
    const confErr = validateConfRecord(c, cw as number | null, cl as number | null);
    if (confErr) { errors.push(`Line ${line}: ${t.name}: ${confErr}`); return; }
    const home = idx.home >= 0 ? parsePair(row[idx.home]) : ([null, null] as [null, null]);
    const away = idx.away >= 0 ? parsePair(row[idx.away]) : ([null, null] as [null, null]);
    if (home === 'bad' || away === 'bad') { errors.push(`Line ${line}: ${t.name} has a Home/Away value that is not like "3-1".`); return; }

    let ap: number | null = null;
    if (idx.ap >= 0) {
      const v = toInt(row[idx.ap]);
      if (v !== null && (Number.isNaN(v) || !Number.isInteger(v) || v < 1 || v > AP_MAX)) {
        errors.push(`Line ${line}: ${t.name} has an AP value outside 1-${AP_MAX}; AP left blank.`);
      } else if (v !== null && apTaken.has(v)) {
        errors.push(`Line ${line}: AP #${v} is already assigned to ${apTaken.get(v)}; ${t.name} left unranked.`);
      } else if (v !== null) { ap = v; apTaken.set(v, t.short); }
    }

    records[t.key] = {
      confW: cw as number | null, confL: cl as number | null, ovW: ow as number | null, ovL: ol as number | null,
      homeW: home[0], homeL: home[1], awayW: away[0], awayL: away[1], ap,
    };
    touched.add(t.key);
    const rk = idx.rk >= 0 ? Number(row[idx.rk]) : NaN;
    (rankByConf[c.id] ??= []).push({ key: t.key, rk: Number.isFinite(rk) ? rk : 9999, line });
    applied++;
  });

  // Teams not in the file keep their records, but their AP rank must not collide with the file's.
  for (const [k, r] of Object.entries(records)) {
    if (!touched.has(k) && r.ap !== null && apTaken.has(r.ap)) {
      errors.push(`AP #${r.ap} from the file replaced the existing assignment for ${k}.`);
      r.ap = null;
    }
  }

  const order = { ...current.order };
  for (const [cid, list] of Object.entries(rankByConf)) {
    const sorted = list.sort((a, b) => a.rk - b.rk || a.line - b.line).map((x) => x.key);
    order[cid] = [...sorted, ...current.order[cid].filter((k) => !sorted.includes(k))];
  }
  return { state: { ...current, order, records }, applied, errors };
}
