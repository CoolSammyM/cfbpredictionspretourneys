import { useState } from 'react';
import { espnIdFor, logoUrl } from '../lib/logos';

interface Props {
  teamKey: string | null;
  espnId: number | null;
  name: string;
  size?: number;
}

/** Official ESPN logo by team id. Falls back to a neutral basketball mark (never initials). */
export default function TeamLogo({ teamKey, espnId, name, size = 24 }: Props) {
  const id = espnIdFor(teamKey, espnId);
  const [failed, setFailed] = useState(false);
  if (!id || failed) {
    return (
      <svg
        className="logo logo-fallback"
        width={size}
        height={size}
        viewBox="0 0 24 24"
        role="img"
        aria-label={`${name} (logo unavailable)`}
      >
        <title>{id ? `${name}: logo failed to load` : `${name}: ESPN id not resolved yet`}</title>
        <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="1.6" />
        <path d="M2 12h20M12 2v20M5 5c4 3 4 11 0 14M19 5c-4 3-4 11 0 14" fill="none" stroke="currentColor" strokeWidth="1.2" />
      </svg>
    );
  }
  return (
    <img
      className="logo"
      src={logoUrl(id)}
      width={size}
      height={size}
      alt={`${name} logo`}
      loading="lazy"
      onError={() => setFailed(true)}
    />
  );
}
