# 2026–27 College Basketball Standings & Schedule Predictor

A static React + TypeScript (Vite) site with two **completely independent** tabs:

1. **Conference Standings**: all 32 Division I conferences, editable records, drag-and-drop rankings, AP poll dropdown, CSV import/export.
2. **Schedule Predictor**: the six power conferences, one full schedule per team, W/L picks, projected records.

There is no backend, no database and no paid service. Everything runs in the browser and saves to that browser's `localStorage`
(standings under `chs.standings.v1`, predictions under `chs.predictor.v1`; neither tab ever reads or writes the other's key).

---

## Publish it for free (GitHub Pages, about 10 minutes, $0)

GitHub Pages is free for public repositories. Private repositories need a paid GitHub plan for Pages, so make the repo **public**.

1. Create a free account at <https://github.com>, then **New repository**. Name it e.g. `hoops-2026-27`, set it **Public**, leave "Add a README" unchecked.
2. Upload this project's contents to the repo. Easiest path with no command line: on the new empty repo page choose **uploading an existing file**, drag in *everything inside this folder* (including the hidden `.github` folder; if your file picker hides it, use the command line below), and commit.
   Command line alternative:
   ```bash
   cd hoops-site
   git init -b main
   git add .
   git commit -m "Initial site"
   git remote add origin https://github.com/<your-username>/hoops-2026-27.git
   git push -u origin main
   ```
3. In the repo go to **Settings → Pages → Build and deployment → Source** and choose **GitHub Actions**.
4. Go to the **Actions** tab. The "Build and deploy to GitHub Pages" workflow starts on every push to `main`. When it turns green, your site is at
   `https://<your-username>.github.io/hoops-2026-27/`.

The workflow runs the tests, then `npm run resolve-ids` (fills in ESPN logo ids; allowed to fail without blocking the deploy), then builds.

### Other genuinely free hosts (no card needed on their free tiers)
- **Cloudflare Pages**: connect the GitHub repo, build command `npm run build`, output directory `dist`.
- **Netlify**: connect the repo, build command `npm run build`, publish directory `dist`.

Free tiers and terms change; check the host's current pricing page before relying on them.

### Run it on your own computer
```bash
npm install
npm run dev        # http://localhost:5173
npm test           # logic tests + render smoke test
npm run build      # produces dist/
```
Requires Node 20+ (the workflow uses Node 22).

---

## How the data works (and what is NOT verified)

**Nothing is made up. Where I could not verify something, the site says so.**

| Item | Status |
|---|---|
| ACC teams and starting order | From your `pickem-standings-acc.csv` (a test checks the code matches the file) |
| Conference game limits (all 32) | Exactly the numbers you gave (a test checks each one) |
| Pac-12, Mountain West, Big Sky, Southern, Big West, Horizon, Sun Belt, WCC, UAC, Big Ten/Big 12/SEC | Checked against the FOX Sports 2026-27 realignment explainer (Nov 2, 2026) and the Pac-12 relaunch announcement. Badge: *Checked against a 2026-27 source* |
| America East | Copied from your screenshot |
| All other conferences (American, A-10, ASUN, Big East, Big South, CAA, Conference USA, Ivy, Metro, MAC, MEAC, MVC, NEC, OVC, Patriot, Southland, SWAC, Summit) | Listed from general knowledge. **Not verified against a 2026-27 source.** Red badge on the page. Please check them |
| Boston College schedule | Games Nov 3–22 exactly as you supplied; Nov 26 onward from ESPN, with the 18 ACC games' dates and home/away cross-checked with bceagles.com. Banner on the page lists the open items |

Open items on the Boston College schedule (also shown in the site):
- Your full supplied schedule did not come through in the second upload, so **anything after Nov 22 is from ESPN, not from you.** If your version differs, tell me and I'll match yours.
- ESPN doesn't print venue names; road venues are the opponents' home arenas (unverified).
- Stanford (Feb 27) has no announced tip time.
- A reported Florida Atlantic home-and-home isn't on ESPN's list, so it's not included.
- No postseason games exist yet (ACC Tournament is March 9–13, 2027 in Greensboro).

### Logos
Logos load from ESPN by **team id** (`https://a.espncdn.com/i/teamlogos/ncaa/500/<id>.png`), never by name. ACC, the six power conferences and the BC opponents have ids written in the data; I wrote those from memory, so run `npm run verify-ids` once (it checks them against ESPN's own team list). `npm run resolve-ids` fills in ids for the remaining teams and lists any it can't match with confidence. A team with no id (or a logo that fails to load) shows a neutral basketball icon, never initials.

### Adding the other teams' schedules
Each team is one file in `src/data/schedules/`, same shape as `boston-college-eagles.ts`, registered in `src/data/schedules/index.ts`. Rules the code enforces: a game with a `result` is final and locked; a game without one is pickable; conference games are detected from the opponent's team key.

### Updating results during the season
Final scores are data, so when a game finishes you add `win(us, them)` (or `result: { us, them }`) to that game in the team's schedule file and push. The site redeploys in about a minute. Any pick you'd saved for that game is dropped automatically because the actual result replaces it. (Automatic score fetching is not built.)

---

## Behaviour notes

- **Auto-sort**: when you save a team's record, its conference re-sorts by conference PCT, highest on top. Ties keep their current order; teams with no conference games entered stay below. Drag-and-drop still works and overrides until the next record edit. You can switch auto-sort off with the checkbox.
- **AP poll**: one dropdown per team (1–25 or unranked). A rank held by another team (in any conference) is greyed out and labeled, e.g. `8 - Duke`.
- **Conference game limit**: a record whose W+L exceeds the conference maximum is rejected with a popup; the editor stays open so you can fix it. Imports are validated the same way.
- **Saving**: data lives in your browser on one device. Clearing site data erases it; it does not sync between phone and laptop. Use **CSV ↓** to back up standings. Predictions have no export yet.

## Project layout
```
src/data/conferences.ts     32 conferences, members, limits, verification badges
src/data/schedules/         one file per team (Boston College so far)
src/lib/standings.ts        PCT, GB, auto-sort, AP uniqueness, validation
src/lib/csv.ts              CSV import/export
src/lib/predictor.ts        projected-record math, picks, month grouping
src/components/             StandingsTab, PredictorTab, TeamLogo, Modal
tests/                      logic tests and render smoke test
scripts/resolve-espn-ids.mjs  ESPN id verification/resolution
```
