import { useEffect, useMemo, useRef, useState } from 'react';
import type { ChangeEvent, FormEvent } from 'react';
import type { Conference, StandingsState, Team, TeamRecord } from '../types';
import { CONFERENCES, TEAM_BY_KEY } from '../data/conferences';
import {
  AP_MAX, apOwners, computeGB, emptyRecord, fmtPair, fmtPct, hasConfGames, initialState, moveItem, pct,
  reconcile, setAp, sortByConfPct, validateConfRecord, validateWholeNumber,
} from '../lib/standings';
import { exportStandingsCsv, importStandingsCsv } from '../lib/csv';
import { loadJson, saveJson, STANDINGS_KEY } from '../lib/storage';
import TeamLogo from './TeamLogo';
import Modal from './Modal';

const UI_KEY = 'chs.standings-ui.v1';
const ALL = 'all';

const VERIF_LABEL = {
  csv: 'Source: your CSV',
  sourced: 'Checked against a 2026-27 source',
  screenshot: 'From your screenshot',
  unverified: 'Unverified roster',
} as const;

function loadState(): StandingsState {
  const saved = loadJson<StandingsState>(STANDINGS_KEY);
  return saved && saved.version === 1 ? reconcile(saved, CONFERENCES) : initialState(CONFERENCES);
}

interface Notice {
  title: string;
  lines: string[];
}

export default function StandingsTab() {
  const [state, setState] = useState<StandingsState>(loadState);
  const [confId, setConfId] = useState<string>(() => loadJson<{ conf: string }>(UI_KEY)?.conf ?? 'acc');
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState<{ conf: Conference; team: Team } | null>(null);
  const [notice, setNotice] = useState<Notice | null>(null);
  const [saveFailed, setSaveFailed] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setSaveFailed(!saveJson(STANDINGS_KEY, state));
  }, [state]);
  useEffect(() => {
    saveJson(UI_KEY, { conf: confId });
  }, [confId]);

  const owners = useMemo(() => apOwners(state), [state]);
  const visible = confId === ALL ? CONFERENCES : CONFERENCES.filter((c) => c.id === confId);
  const q = query.trim().toLowerCase();

  // ---- actions ----
  const reorder = (cid: string, from: number, to: number) =>
    setState((s) => ({ ...s, order: { ...s.order, [cid]: moveItem(s.order[cid], from, to) } }));

  const saveRecord = (conf: Conference, teamKey: string, rec: TeamRecord) => {
    setState((s) => {
      const records = { ...s.records, [teamKey]: rec };
      const order = s.autoSort ? { ...s.order, [conf.id]: sortByConfPct(s.order[conf.id], records) } : s.order;
      return { ...s, records, order };
    });
  };

  const pickAp = (teamKey: string, value: string) => {
    const rank = value === '' ? null : Number(value);
    const res = setAp(state, teamKey, rank, TEAM_BY_KEY);
    if (res.error) setNotice({ title: 'AP rank not changed', lines: [res.error] });
    else setState(res.state);
  };

  const toggleAutoSort = (on: boolean) =>
    setState((s) => {
      if (!on) return { ...s, autoSort: false };
      const order = Object.fromEntries(CONFERENCES.map((c) => [c.id, sortByConfPct(s.order[c.id], s.records)]));
      return { ...s, autoSort: true, order };
    });

  const resetConference = (c: Conference) => {
    if (!window.confirm(`Reset ${c.name}? This clears its records and AP ranks and restores the default order.`)) return;
    setState((s) => {
      const base = initialState([c]);
      const records = { ...s.records };
      for (const t of c.teams) records[t.key] = emptyRecord();
      return { ...s, records, order: { ...s.order, [c.id]: base.order[c.id] } };
    });
  };

  const resetAll = () => {
    if (!window.confirm('Reset ALL conference standings, AP ranks and rankings? Your Schedule Predictor picks are not affected.')) return;
    setState(initialState(CONFERENCES));
  };

  const exportCsv = () => {
    const csv = exportStandingsCsv(state, CONFERENCES, confId === ALL ? undefined : confId);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = confId === ALL ? 'standings-2026-27-all.csv' : `standings-2026-27-${confId}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const onImport = async (file: File | undefined) => {
    if (!file) return;
    try {
      const text = await file.text();
      const res = importStandingsCsv(text, state, CONFERENCES);
      if (res.applied > 0) setState(res.state);
      setNotice({
        title: res.applied > 0 ? `Imported ${res.applied} team${res.applied === 1 ? '' : 's'}` : 'Nothing imported',
        lines: res.errors.length ? res.errors.slice(0, 12).concat(res.errors.length > 12 ? [`…and ${res.errors.length - 12} more`] : []) : ['All rows were valid.'],
      });
    } catch {
      setNotice({ title: 'Import failed', lines: ['That file could not be read.'] });
    }
    if (fileRef.current) fileRef.current.value = '';
  };

  return (
    <section aria-labelledby="st-h">
      <div className="page-head">
        <div>
          <h1 id="st-h">2026–27 Standings</h1>
          <p className="sub">Your predicted finish. Enter records, drag to rank. 32 conferences.</p>
        </div>
        <div className="toolbar">
          <select aria-label="Conference filter" value={confId} onChange={(e) => setConfId(e.target.value)}>
            <option value={ALL}>All conferences</option>
            {CONFERENCES.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <input type="search" aria-label="Search team" placeholder="Search team" value={query} onChange={(e) => setQuery(e.target.value)} />
          <button className="btn" onClick={exportCsv} title="Download standings as CSV">
            CSV ↓
          </button>
          <button className="btn" onClick={() => fileRef.current?.click()} title="Import a standings CSV">
            Import ↑
          </button>
          <input ref={fileRef} type="file" accept=".csv,text/csv" hidden onChange={(e) => onImport(e.target.files?.[0])} />
        </div>
      </div>

      <div className="options">
        <label className="check">
          <input type="checkbox" checked={state.autoSort} onChange={(e) => toggleAutoSort(e.target.checked)} />
          Auto-sort by conference PCT when I edit a record (highest on top)
        </label>
        <button className="link" onClick={resetAll}>
          Reset all standings
        </button>
      </div>

      {saveFailed && (
        <div className="banner banner-warn">Your browser blocked saving, so changes will be lost on refresh. Use CSV export to keep a copy.</div>
      )}

      {visible.map((c) => (
        <ConferenceTable
          key={c.id}
          conf={c}
          state={state}
          owners={owners}
          query={q}
          onMove={(from, to) => reorder(c.id, from, to)}
          onEdit={(team) => setEditing({ conf: c, team })}
          onAp={pickAp}
          onReset={() => resetConference(c)}
        />
      ))}

      {editing && (
        <RecordEditor
          conf={editing.conf}
          team={editing.team}
          record={state.records[editing.team.key]}
          autoSort={state.autoSort}
          onCancel={() => setEditing(null)}
          onSave={(rec) => {
            saveRecord(editing.conf, editing.team.key, rec);
            setEditing(null);
          }}
          onInvalid={(lines) => setNotice({ title: 'Record not saved', lines })}
        />
      )}
      {notice && (
        <Modal title={notice.title} tone={notice.title.startsWith('Imported') ? 'info' : 'warn'} onClose={() => setNotice(null)}>
          {notice.lines.map((l, i) => (
            <p key={i}>{l}</p>
          ))}
        </Modal>
      )}
    </section>
  );
}

// ---------------------------------------------------------------------------

interface TableProps {
  conf: Conference;
  state: StandingsState;
  owners: Record<number, string>;
  query: string;
  onMove: (from: number, to: number) => void;
  onEdit: (team: Team) => void;
  onAp: (teamKey: string, value: string) => void;
  onReset: () => void;
}

function ConferenceTable({ conf, state, owners, query, onMove, onEdit, onAp, onReset }: TableProps) {
  const order = state.order[conf.id];
  const gb = useMemo(() => computeGB(order, state.records), [order, state.records]);
  const dragFrom = useRef<number | null>(null);
  const [over, setOver] = useState<number | null>(null);
  const teams = conf.teams;
  const byKey = (k: string) => teams.find((t) => t.key === k)!;
  const entered = order.filter((k) => hasConfGames(state.records[k])).length;
  const anyEntered = entered > 0;
  const sortedNow = JSON.stringify(sortByConfPct(order, state.records)) === JSON.stringify(order);
  const status = !anyEntered ? 'Default order. Drag to rank.' : sortedNow ? 'Sorted by conference PCT' : 'Manual order. Re-sorts on next edit';
  const filtering = query !== '';
  const rows = order
    .map((key, i) => ({ key, i }))
    .filter(({ key }) => !filtering || byKey(key).name.toLowerCase().includes(query) || byKey(key).short.toLowerCase().includes(query));

  if (filtering && rows.length === 0) return null;

  return (
    <div className="conf-block">
      <div className="conf-head">
        <h2>{conf.name}</h2>
        <span className="mono muted">
          {conf.maxConfGames}-game max · {entered}/{teams.length} entered
        </span>
        <span className={`verif verif-${conf.verification}`} title={conf.note ?? ''}>
          {VERIF_LABEL[conf.verification]}
        </span>
        <span className="spacer" />
        <span className="status">{status}</span>
        <button className="link" onClick={onReset}>
          ↺ Reset
        </button>
      </div>
      {conf.verification === 'unverified' && conf.note && <p className="conf-note">{conf.note}</p>}

      <div className="table-wrap">
        <table className="st">
          <thead>
            <tr className="grp">
              <th colSpan={2} className="rk-col" />
              <th className="team-col" />
              <th colSpan={4}>CONFERENCE</th>
              <th colSpan={5}>OVERALL</th>
              <th colSpan={1}>POLLS</th>
              <th className="edit-col" />
            </tr>
            <tr>
              <th className="rk-col" colSpan={2}>RK</th>
              <th className="team-col left">TEAM</th>
              <th>W</th>
              <th>L</th>
              <th>GB</th>
              <th className="hl">PCT</th>
              <th>W</th>
              <th>L</th>
              <th className="hl">PCT</th>
              <th>HOME</th>
              <th>AWAY</th>
              <th title="AP poll rank. Each rank can belong to one team.">AP</th>
              <th className="edit-col" />
            </tr>
          </thead>
          <tbody>
            {rows.map(({ key, i }) => {
              const t = byKey(key);
              const r = state.records[key];
              const cp = pct(r.confW, r.confL);
              const op = pct(r.ovW, r.ovL);
              const has = hasConfGames(r);
              return (
                <tr
                  key={key}
                  className={over === i ? 'drop-target' : ''}
                  draggable={!filtering}
                  onDragStart={(e) => {
                    dragFrom.current = i;
                    e.dataTransfer.effectAllowed = 'move';
                    e.dataTransfer.setData('text/plain', key);
                  }}
                  onDragOver={(e) => {
                    if (filtering) return;
                    e.preventDefault();
                    setOver(i);
                  }}
                  onDragLeave={() => setOver((o) => (o === i ? null : o))}
                  onDrop={(e) => {
                    e.preventDefault();
                    if (dragFrom.current !== null) onMove(dragFrom.current, i);
                    dragFrom.current = null;
                    setOver(null);
                  }}
                  onDragEnd={() => {
                    dragFrom.current = null;
                    setOver(null);
                  }}
                >
                  <td className="grip" aria-hidden="true" title={filtering ? 'Clear search to drag' : 'Drag to rank'}>
                    ⋮⋮
                  </td>
                  <td className="rk">
                    <span className="rk-num">{i + 1}</span>
                    <span className="arrows">
                      <button aria-label={`Move ${t.short} up`} disabled={i === 0 || filtering} onClick={() => onMove(i, i - 1)}>
                        ↑
                      </button>
                      <button aria-label={`Move ${t.short} down`} disabled={i === order.length - 1 || filtering} onClick={() => onMove(i, i + 1)}>
                        ↓
                      </button>
                    </span>
                  </td>
                  <td className="team-col left">
                    <span className="team">
                      <TeamLogo teamKey={t.key} espnId={t.espnId} name={t.name} size={24} />
                      <span className="team-name">{t.name}</span>
                    </span>
                  </td>
                  <td className="num">{r.confW ?? '·'}</td>
                  <td className="num">{r.confL ?? '·'}</td>
                  <td className="num">{has ? gb[key] : '·'}</td>
                  <td className="num hl">{fmtPct(cp) === '—' ? '·' : fmtPct(cp)}</td>
                  <td className="num">{r.ovW ?? '·'}</td>
                  <td className="num">{r.ovL ?? '·'}</td>
                  <td className="num hl">{fmtPct(op) === '—' ? '·' : fmtPct(op)}</td>
                  <td className="num">{fmtPair(r.homeW, r.homeL)}</td>
                  <td className="num">{fmtPair(r.awayW, r.awayL)}</td>
                  <td className="ap-cell">
                    <select
                      className={r.ap ? 'ap ranked' : 'ap'}
                      aria-label={`AP rank for ${t.short}`}
                      value={r.ap ?? ''}
                      onChange={(e) => onAp(key, e.target.value)}
                    >
                      <option value="">—</option>
                      {Array.from({ length: AP_MAX }, (_, n) => n + 1).map((n) => {
                        const owner = owners[n];
                        const takenByOther = !!owner && owner !== key;
                        return (
                          <option key={n} value={n} disabled={takenByOther}>
                            {takenByOther ? `${n} - ${TEAM_BY_KEY[owner]?.short ?? owner}` : n}
                          </option>
                        );
                      })}
                    </select>
                  </td>
                  <td className="edit-col">
                    <button className="icon-btn" aria-label={`Edit ${t.short} records`} title="Edit records" onClick={() => onEdit(t)}>
                      ✎
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------

interface EditorProps {
  conf: Conference;
  team: Team;
  record: TeamRecord;
  autoSort: boolean;
  onCancel: () => void;
  onSave: (r: TeamRecord) => void;
  onInvalid: (lines: string[]) => void;
}

const toField = (v: number | null) => (v === null ? '' : String(v));

function RecordEditor({ conf, team, record, autoSort, onCancel, onSave, onInvalid }: EditorProps) {
  const [f, setF] = useState({
    confW: toField(record.confW), confL: toField(record.confL), ovW: toField(record.ovW), ovL: toField(record.ovL),
    homeW: toField(record.homeW), homeL: toField(record.homeL), awayW: toField(record.awayW), awayL: toField(record.awayL),
  });
  const set = (k: keyof typeof f) => (e: ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  const parse = (s: string): number | null => (s.trim() === '' ? null : /^\d+$/.test(s.trim()) ? Number(s.trim()) : NaN);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const v = Object.fromEntries(Object.entries(f).map(([k, s]) => [k, parse(s)])) as Record<keyof typeof f, number | null>;
    const labels: Record<keyof typeof f, string> = {
      confW: 'Conference wins', confL: 'Conference losses', ovW: 'Overall wins', ovL: 'Overall losses',
      homeW: 'Home wins', homeL: 'Home losses', awayW: 'Away wins', awayL: 'Away losses',
    };
    const problems: string[] = [];
    for (const k of Object.keys(v) as (keyof typeof f)[]) {
      const x = v[k];
      const msg = Number.isNaN(x as number) ? `${labels[k]} must be a whole number of 0 or more.` : validateWholeNumber(labels[k], x);
      if (msg) problems.push(msg);
    }
    if (problems.length === 0) {
      const err = validateConfRecord(conf, v.confW, v.confL);
      if (err) problems.push(err);
    }
    if (problems.length) {
      onInvalid(problems);
      return; // the editor stays open with your entries so you can fix them
    }
    onSave({ ...record, ...v });
  };

  const total = (parse(f.confW) || 0) + (parse(f.confL) || 0);
  const over = total > conf.maxConfGames;

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(e) => e.target === e.currentTarget && onCancel()}>
      <form className="modal editor" onSubmit={submit} aria-label={`Edit ${team.name}`}>
        <h3 className="editor-title">
          <TeamLogo teamKey={team.key} espnId={team.espnId} name={team.name} size={32} /> {team.name}
        </h3>
        <fieldset>
          <legend>
            Conference <span className={over ? 'over' : 'muted'}>({total}/{conf.maxConfGames} games max)</span>
          </legend>
          <label>W <input inputMode="numeric" value={f.confW} onChange={set('confW')} /></label>
          <label>L <input inputMode="numeric" value={f.confL} onChange={set('confL')} /></label>
        </fieldset>
        <fieldset>
          <legend>Overall</legend>
          <label>W <input inputMode="numeric" value={f.ovW} onChange={set('ovW')} /></label>
          <label>L <input inputMode="numeric" value={f.ovL} onChange={set('ovL')} /></label>
        </fieldset>
        <fieldset>
          <legend>Home</legend>
          <label>W <input inputMode="numeric" value={f.homeW} onChange={set('homeW')} /></label>
          <label>L <input inputMode="numeric" value={f.homeL} onChange={set('homeL')} /></label>
        </fieldset>
        <fieldset>
          <legend>Away</legend>
          <label>W <input inputMode="numeric" value={f.awayW} onChange={set('awayW')} /></label>
          <label>L <input inputMode="numeric" value={f.awayL} onChange={set('awayL')} /></label>
        </fieldset>
        <p className="hint">
          PCT and GB are calculated for you.{autoSort ? ` ${conf.name} will re-sort by conference PCT after you save.` : ''}
        </p>
        <div className="modal-actions">
          <button type="button" className="btn" onClick={onCancel}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary">
            Save
          </button>
        </div>
      </form>
    </div>
  );
}
