#!/usr/bin/env node
/**
 * Resolves / verifies ESPN team ids using ESPN's own public team list.
 *
 *   npm run verify-ids    Check every id written in the data files against ESPN. Reports mismatches. Writes nothing.
 *   npm run resolve-ids   Same check, then writes src/data/espn-ids.generated.json with ids for teams that
 *                         have no id in the data files. Teams that cannot be matched with confidence are
 *                         listed and left without an id (the site shows a neutral fallback logo for them).
 *
 * Needs normal internet access (it calls site.api.espn.com). It does not run inside the sandbox this
 * project was authored in, so run it once on your machine or let the GitHub Action run it.
 *
 * Matching is by ESPN's school name ("location") only for teams that have no explicit id, and an
 * ambiguous name is never guessed. The logo itself is always loaded by id.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const verifyOnly = process.argv.includes('--verify');
const URL_TEAMS = 'https://site.api.espn.com/apis/site/v2/sports/basketball/mens-college-basketball/teams?limit=1000&groups=50';

const norm = (s) =>
  s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/&/g, 'and').replace(/\bsaint\b/g, 'st').replace(/[^a-z0-9]+/g, ' ').trim();

// Our school names that ESPN spells differently.
const ALIASES = {
  'uconn': 'connecticut', 'ole miss': 'ole miss', 'umass': 'massachusetts', 'uab': 'uab', 'ucf': 'ucf',
  'miami oh': 'miami oh', 'louisiana monroe': 'ul monroe', 'louisiana': 'louisiana', 'southern miss': 'southern miss',
  'cal baptist': 'california baptist', 'iu indy': 'iu indianapolis', 'fiu': 'fiu', 'vmi': 'vmi',
  'the citadel': 'the citadel', 'ut martin': 'ut martin', 'little rock': 'little rock', 'kansas city': 'kansas city',
  'omaha': 'omaha', 'liu': 'liu', 'unc greensboro': 'unc greensboro', 'unc asheville': 'unc asheville',
  'unc wilmington': 'unc wilmington', 'texas a and m corpus christi': 'texas a and m corpus christi',
};

async function main() {
  const res = await fetch(URL_TEAMS);
  if (!res.ok) throw new Error(`ESPN responded ${res.status}`);
  const json = await res.json();
  const espn = json.sports[0].leagues[0].teams.map((t) => t.team);
  const byId = new Map(espn.map((t) => [Number(t.id), t]));
  const byName = new Map();
  for (const t of espn) {
    for (const n of [t.location, t.shortDisplayName, t.displayName]) {
      const k = norm(n ?? '');
      if (!k) continue;
      byName.set(k, byName.has(k) && byName.get(k).id !== t.id ? 'AMBIGUOUS' : t);
    }
  }

  // Load our teams by importing the TS data through a tiny regex-free path: use tsx if available, else parse JSON export.
  const { CONFERENCES } = await import(join(here, '../src/data/conferences.ts')).catch(() => {
    console.error('Run this through tsx:  npx tsx scripts/resolve-espn-ids.mjs   (npm run resolve-ids does this for you)');
    process.exit(2);
  });
  const { SCHEDULES } = await import(join(here, '../src/data/schedules/index.ts'));

  const teams = new Map();
  for (const c of CONFERENCES) for (const t of c.teams) teams.set(t.key, { name: t.short, full: t.name, id: t.espnId });
  for (const s of Object.values(SCHEDULES)) {
    for (const g of s.games) if (g.opp.key && !teams.has(g.opp.key)) teams.set(g.opp.key, { name: g.opp.name, full: g.opp.name, id: g.opp.espnId });
  }

  const mismatched = [];
  const generated = {};
  const unresolved = [];
  for (const [key, t] of teams) {
    if (t.id) {
      const e = byId.get(t.id);
      if (!e) mismatched.push(`${t.full}: id ${t.id} is not in ESPN's list`);
      else {
        const ok = [e.location, e.displayName, e.shortDisplayName].some((n) => norm(n).includes(norm(t.name)) || norm(t.name).includes(norm(n)));
        if (!ok) mismatched.push(`${t.full}: id ${t.id} is ESPN's "${e.displayName}"`);
      }
      continue;
    }
    const k = ALIASES[norm(t.name)] ?? norm(t.name);
    const hit = byName.get(k);
    if (hit && hit !== 'AMBIGUOUS') generated[key] = { id: Number(hit.id), displayName: hit.displayName };
    else unresolved.push(`${t.full}${hit === 'AMBIGUOUS' ? ' (ambiguous)' : ''}`);
  }

  console.log(`Teams checked: ${teams.size}`);
  console.log(mismatched.length ? `\nID MISMATCHES (fix these in the data files):\n - ${mismatched.join('\n - ')}` : '\nAll explicit ids match ESPN.');
  if (!verifyOnly) {
    writeFileSync(join(here, '../src/data/espn-ids.generated.json'), JSON.stringify(generated, null, 2) + '\n');
    console.log(`\nWrote ${Object.keys(generated).length} resolved ids to src/data/espn-ids.generated.json`);
  }
  console.log(unresolved.length ? `\nNo confident match (fallback logo will show):\n - ${unresolved.join('\n - ')}` : '\nEvery team resolved.');
  if (mismatched.length) process.exitCode = 1;
}

main().catch((e) => {
  console.error(e.message);
  process.exit(2);
});
