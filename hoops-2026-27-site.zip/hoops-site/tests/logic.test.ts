import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { ALL_TEAMS, CONFERENCES, POWER_CONFERENCES, TEAM_BY_KEY } from '../src/data/conferences';
import { SCHEDULES } from '../src/data/schedules';
import {
  apOwners, computeGB, fmtPct, initialState, moveItem, pct, reconcile, setAp, sortByConfPct, validateConfRecord,
} from '../src/lib/standings';
import { exportStandingsCsv, importStandingsCsv, parseCsv } from '../src/lib/csv';
import { cleanPicks, fmtRec, groupByMonth, resetTeamPicks, setPick, summarize } from '../src/lib/predictor';
import { emptyPredictorState } from '../src/lib/predictor';
import { PREDICTOR_KEY, STANDINGS_KEY } from '../src/lib/storage';

const here = dirname(fileURLToPath(import.meta.url));
let passed = 0;
const test = (name: string, fn: () => void) => {
  try { fn(); passed++; console.log(`  ok  ${name}`); } catch (e) { console.error(`FAIL  ${name}\n`, e); process.exitCode = 1; }
};

const MAX: Record<string, number> = {
  'America East': 16, American: 18, 'Atlantic 10': 18, ACC: 18, ASUN: 14, 'Big 12': 18, 'Big East': 20, 'Big Sky': 20,
  'Big South': 16, 'Big Ten': 20, 'Big West': 20, CAA: 18, 'Conference USA': 18, 'Horizon League': 20, 'Ivy League': 14,
  'Metro Conference (formerly MAAC)': 20, MAC: 18, MEAC: 14, 'Missouri Valley': 20, 'Mountain West': 20, NEC: 16, OVC: 18,
  'Pac-12': 16, 'Patriot League': 18, SEC: 18, Southern: 18, Southland: 20, SWAC: 18, 'Summit League': 16, 'Sun Belt': 18,
  UAC: 18, WCC: 16,
};

console.log('Conference data');
test('all 32 conferences present with the exact game limits', () => {
  assert.equal(CONFERENCES.length, 32);
  for (const c of CONFERENCES) assert.equal(c.maxConfGames, MAX[c.name], c.name);
  assert.equal(new Set(CONFERENCES.map((c) => c.name)).size, 32);
  assert.deepEqual(new Set(CONFERENCES.map((c) => c.name)), new Set(Object.keys(MAX)));
});
test('team keys are unique and every conference has teams', () => {
  assert.equal(new Set(ALL_TEAMS.map((t) => t.key)).size, ALL_TEAMS.length);
  for (const c of CONFERENCES) assert.ok(c.teams.length >= 7, c.name);
});
test('ACC order matches pickem-standings-acc.csv', () => {
  const rows = parseCsv(readFileSync(join(here, '../public/pickem-standings-acc.csv'), 'utf8')).slice(1);
  const acc = CONFERENCES.find((c) => c.id === 'acc')!;
  assert.deepEqual(rows.map((r) => r[2]), acc.teams.map((t) => t.name));
  assert.deepEqual(rows.map((r) => Number(r[1])), rows.map((_, i) => i + 1));
});
test('six power conferences, sizes', () => {
  assert.deepEqual(POWER_CONFERENCES.map((c) => c.name), ['ACC', 'Big Ten', 'Big 12', 'Big East', 'Pac-12', 'SEC']);
  assert.equal(POWER_CONFERENCES.find((c) => c.id === 'pac-12')!.teams.length, 9);
});

console.log('Standings logic');
const acc = CONFERENCES.find((c) => c.id === 'acc')!;
const fresh = () => initialState(CONFERENCES);
test('pct / format', () => {
  assert.equal(pct(0, 0), null);
  assert.equal(fmtPct(pct(2, 1)), '.667');
  assert.equal(fmtPct(pct(5, 0)), '1.000');
  assert.equal(fmtPct(pct(0, 3)), '.000');
});
test('conference limit rejects over-max, accepts exactly max', () => {
  assert.ok(validateConfRecord(acc, 10, 9));
  assert.equal(validateConfRecord(acc, 10, 8), null);
  const ivy = CONFERENCES.find((c) => c.id === 'ivy')!;
  assert.ok(validateConfRecord(ivy, 8, 7));
  assert.equal(validateConfRecord(ivy, 7, 7), null);
  assert.ok(validateConfRecord(acc, -1, 2));
  assert.ok(validateConfRecord(acc, 1.5, 2));
});
test('auto-sort: higher conference PCT on top, lower at bottom, ties keep order, blanks last', () => {
  const s = fresh();
  const r = s.records;
  r['duke-blue-devils'] = { ...r['duke-blue-devils'], confW: 10, confL: 8 }; // .556
  r['clemson-tigers'] = { ...r['clemson-tigers'], confW: 15, confL: 3 }; // .833
  r['stanford-cardinal'] = { ...r['stanford-cardinal'], confW: 5, confL: 13 }; // .278
  r['virginia-cavaliers'] = { ...r['virginia-cavaliers'], confW: 10, confL: 8 }; // .556 tie with Duke
  const sorted = sortByConfPct(s.order.acc, r);
  assert.deepEqual(sorted.slice(0, 4), ['clemson-tigers', 'duke-blue-devils', 'virginia-cavaliers', 'stanford-cardinal']);
  assert.equal(sorted.length, 18);
  assert.equal(sorted[4], 'boston-college-eagles'); // blanks keep CSV order after the entered teams
  assert.equal(sorted[17], 'wake-forest-demon-deacons');
});
test('PCT, not raw wins: 6-2 (.750) ranks above 10-8 (.556)', () => {
  const s = fresh();
  s.records['duke-blue-devils'] = { ...s.records['duke-blue-devils'], confW: 10, confL: 8 };
  s.records['miami-hurricanes'] = { ...s.records['miami-hurricanes'], confW: 6, confL: 2 };
  assert.deepEqual(sortByConfPct(s.order.acc, s.records).slice(0, 2), ['miami-hurricanes', 'duke-blue-devils']);
});
test('games behind', () => {
  const s = fresh();
  s.records['clemson-tigers'] = { ...s.records['clemson-tigers'], confW: 15, confL: 3 };
  s.records['duke-blue-devils'] = { ...s.records['duke-blue-devils'], confW: 10, confL: 8 };
  const gb = computeGB(s.order.acc, s.records);
  assert.equal(gb['clemson-tigers'], '-');
  assert.equal(gb['duke-blue-devils'], '5');
  assert.equal(gb['boston-college-eagles'], '-');
  s.records['stanford-cardinal'] = { ...s.records['stanford-cardinal'], confW: 14, confL: 3 };
  assert.equal(computeGB(s.order.acc, s.records)['stanford-cardinal'], '0.5');
});
test('drag/move keeps list intact', () => {
  assert.deepEqual(moveItem(['a', 'b', 'c', 'd'], 0, 2), ['b', 'c', 'a', 'd']);
  assert.deepEqual(moveItem(['a', 'b'], 1, 5), ['a', 'b']);
});
test('AP ranks are exclusive across all teams (national poll)', () => {
  let s = fresh();
  let res = setAp(s, 'duke-blue-devils', 8, TEAM_BY_KEY);
  assert.equal(res.error, undefined);
  s = res.state;
  res = setAp(s, 'michigan', 8, TEAM_BY_KEY); // different conference
  assert.match(res.error!, /already taken by Duke/);
  assert.equal(res.state.records['michigan'].ap, null);
  assert.equal(apOwners(s)[8], 'duke-blue-devils');
  res = setAp(s, 'duke-blue-devils', 8, TEAM_BY_KEY); // re-selecting own rank is fine
  assert.equal(res.error, undefined);
  res = setAp(s, 'duke-blue-devils', null, TEAM_BY_KEY); // clearing frees it
  assert.equal(apOwners(res.state)[8], undefined);
  assert.ok(setAp(s, 'michigan', 26, TEAM_BY_KEY).error);
});
test('reconcile drops duplicate AP ranks from corrupt saved data', () => {
  const s = fresh();
  s.records['duke-blue-devils'].ap = 3;
  s.records['michigan'].ap = 3;
  const r = reconcile(s, CONFERENCES);
  assert.equal(Object.values(r.records).filter((x) => x.ap === 3).length, 1);
});

console.log('CSV');
test('export has no USA column and round-trips through import', () => {
  let s = fresh();
  s.records['duke-blue-devils'] = { ...s.records['duke-blue-devils'], confW: 12, confL: 6, ovW: 25, ovL: 6, homeW: 15, homeL: 1, awayW: 8, awayL: 4, ap: 2 };
  s.order.acc = moveItem(s.order.acc, 0, 5);
  const csv = exportStandingsCsv(s, CONFERENCES);
  const header = parseCsv(csv)[0];
  assert.ok(!header.includes('USA'));
  assert.deepEqual(header.slice(-3), ['Home', 'Away', 'AP']);
  const back = importStandingsCsv(csv, fresh(), CONFERENCES);
  assert.deepEqual(back.errors, []);
  assert.deepEqual(back.state.order.acc, s.order.acc);
  assert.deepEqual(back.state.records['duke-blue-devils'], s.records['duke-blue-devils']);
});
test('importing the provided ACC csv keeps its order', () => {
  const text = readFileSync(join(here, '../public/pickem-standings-acc.csv'), 'utf8');
  const r = importStandingsCsv(text, fresh(), CONFERENCES);
  assert.deepEqual(r.errors, []);
  assert.equal(r.applied, 18);
  assert.deepEqual(r.state.order.acc, acc.teams.map((t) => t.key));
});
test('import rejects over-limit conference records and duplicate AP ranks', () => {
  const csv = [
    '"Conference","RK","Team","Conf W","Conf L","Overall W","Overall L","AP"',
    '"ACC","1","Duke Blue Devils","15","10","","","4"',
    '"ACC","2","Clemson Tigers","10","8","","","4"',
  ].join('\n');
  const r = importStandingsCsv(csv, fresh(), CONFERENCES);
  assert.equal(r.applied, 1);
  assert.ok(r.errors.some((e) => /at most 18/.test(e)));
  assert.equal(r.state.records['duke-blue-devils'].confW, null); // rejected row not applied
  assert.equal(r.state.records['clemson-tigers'].ap, 4);
});
test('csv quoting', () => {
  assert.deepEqual(parseCsv('a,"b,c","d ""q"""\n1,2,3'), [['a', 'b,c', 'd "q"'], ['1', '2', '3']]);
});

console.log('Schedule predictor — Boston College');
const bc = SCHEDULES['boston-college-eagles'];
const accKeys = new Set(acc.teams.map((t) => t.key));
test('BC has your six supplied games, exactly as given, all locked', () => {
  const six = bc.games.slice(0, 6);
  assert.deepEqual(
    six.map((g) => [g.date, g.opp.name.split(' ')[0], g.site, `${g.result!.us}-${g.result!.them}`]),
    [
      ['2026-11-03', 'Wagner', 'home', '76-50'], ['2026-11-06', 'Massachusetts', 'neutral', '71-55'],
      ['2026-11-10', 'Maryland', 'home', '82-54'], ['2026-11-15', 'New', 'home', '67-55'],
      ['2026-11-18', 'Harvard', 'away', '74-69'], ['2026-11-22', 'NJIT', 'home', '79-59'],
    ],
  );
  assert.ok(bc.games.slice(6).every((g) => !g.result));
});
test('32 games, 18 conference (9 home / 9 away), unique ids, chronological in month groups', () => {
  assert.equal(bc.games.length, 32);
  assert.equal(new Set(bc.games.map((g) => g.id)).size, 32);
  const conf = bc.games.filter((g) => g.opp.key && accKeys.has(g.opp.key));
  assert.equal(conf.length, 18);
  assert.equal(conf.filter((g) => g.site === 'home').length, 9);
  assert.equal(conf.filter((g) => g.site === 'away').length, 9);
  const groups = groupByMonth(bc.games);
  assert.deepEqual(groups.map((x) => x.label), ['November 2026', 'December 2026', 'January 2027', 'February 2027', 'March 2027']);
  const dates = groups.flatMap((x) => x.games.map((g) => g.date));
  assert.deepEqual(dates, [...dates].sort());
});
test('baseline: actual 6-0 overall, 0-0 ACC; remaining 26; unpicked 26 (matches your screenshot)', () => {
  const s = summarize(bc, {}, accKeys);
  assert.equal(fmtRec(s.actualOverall), '6-0');
  assert.equal(fmtRec(s.projOverall), '6-0');
  assert.equal(fmtRec(s.actualConf), '0-0');
  assert.equal(fmtRec(s.projConf), '0-0');
  assert.equal(fmtRec(s.projHome), '4-0'); // Wagner, UMES, UNH, NJIT
  assert.equal(fmtRec(s.projAway), '1-0'); // Harvard; UMass at TD Garden is neutral
  assert.equal(s.remaining, 26);
  assert.equal(s.unpicked, 26);
});
test('picks change projections only; unpicked count as nothing; neutral not home/away; conf only ACC', () => {
  const ucf = bc.games.find((g) => g.opp.key === 'ucf')!;
  const unc = bc.games.find((g) => g.opp.key === 'north-carolina-tar-heels')!;
  const vtAway = bc.games.find((g) => g.opp.key === 'virginia-tech-hokies' && g.site === 'away')!;
  const picks = { [ucf.id]: 'W', [unc.id]: 'L', [vtAway.id]: 'W' } as const;
  const s = summarize(bc, picks, accKeys);
  assert.equal(fmtRec(s.actualOverall), '6-0');
  assert.equal(fmtRec(s.projOverall), '8-1');
  assert.equal(fmtRec(s.projConf), '1-1');
  assert.equal(fmtRec(s.projHome), '4-1'); // UNC loss at home
  assert.equal(fmtRec(s.projAway), '2-0'); // VT win on the road
  assert.equal(s.unpicked, 23);
  assert.equal(s.remaining, 26);
});
test('completed results are locked: picks on final games are ignored', () => {
  const wagner = bc.games[0];
  const st = setPick(emptyPredictorState(), bc, wagner.id, 'L');
  assert.deepEqual(st.picks, {});
  const s = summarize(bc, { [wagner.id]: 'L' }, accKeys);
  assert.equal(fmtRec(s.projOverall), '6-0');
});
test('set, clear, reset, and per-team persistence', () => {
  const ucf = bc.games.find((g) => g.opp.key === 'ucf')!;
  const cin = bc.games.find((g) => g.opp.key === 'cincinnati')!;
  let st = setPick(emptyPredictorState(), bc, ucf.id, 'W');
  st = setPick(st, bc, cin.id, 'L');
  assert.equal(Object.keys(st.picks['boston-college-eagles']).length, 2);
  st = setPick(st, bc, ucf.id, null);
  assert.deepEqual(Object.keys(st.picks['boston-college-eagles']), [cin.id]);
  st = { ...st, picks: { ...st.picks, 'duke-blue-devils': { x: 'W' } } };
  st = resetTeamPicks(st, 'boston-college-eagles');
  assert.equal(st.picks['boston-college-eagles'], undefined);
  assert.deepEqual(st.picks['duke-blue-devils'], { x: 'W' }); // other team untouched
});
test('cleanPicks drops stale picks', () => {
  const ucf = bc.games.find((g) => g.opp.key === 'ucf')!;
  const st = cleanPicks({ version: 1, picks: { 'boston-college-eagles': { [ucf.id]: 'W', [bc.games[0].id]: 'W', nope: 'L' } } }, SCHEDULES);
  assert.deepEqual(st.picks['boston-college-eagles'], { [ucf.id]: 'W' });
});

console.log('Tab independence');
test('separate storage keys', () => {
  assert.notEqual(STANDINGS_KEY, PREDICTOR_KEY);
});
test('standings functions never touch predictor state and vice versa', () => {
  const ps = emptyPredictorState();
  const frozenP = JSON.stringify(ps);
  const s0 = fresh();
  const frozenS = JSON.stringify(s0);
  const ucf = bc.games.find((g) => g.opp.key === 'ucf')!;
  const s1 = setAp(s0, 'duke-blue-devils', 1, TEAM_BY_KEY).state;
  const p1 = setPick(ps, bc, ucf.id, 'W');
  assert.equal(JSON.stringify(ps), frozenP); // inputs are not mutated
  assert.equal(JSON.stringify(s0), frozenS);
  assert.ok(!('picks' in s1) && !('records' in p1));
});
test('importing standings leaves predictor untouched (different modules, different state shape)', () => {
  const ps = setPick(emptyPredictorState(), bc, bc.games.find((g) => g.opp.key === 'ucf')!.id, 'W');
  const before = JSON.stringify(ps);
  importStandingsCsv(readFileSync(join(here, '../public/pickem-standings-acc.csv'), 'utf8'), fresh(), CONFERENCES);
  assert.equal(JSON.stringify(ps), before);
});

console.log(`\n${passed} tests passed`);
