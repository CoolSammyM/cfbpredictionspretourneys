import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' makes the build work from any sub-path (GitHub Pages project sites,
// Cloudflare Pages, Netlify, or just opening dist/ behind any static server).
export default defineConfig({
  base: './',
  plugins: [react()],
});
