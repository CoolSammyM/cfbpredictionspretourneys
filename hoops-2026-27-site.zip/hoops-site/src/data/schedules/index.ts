import type { TeamSchedule } from '../../types';
import { BOSTON_COLLEGE } from './boston-college-eagles';

/**
 * One file per team, same shape as boston-college-eagles.ts. Only Boston College is loaded for now;
 * the other ~70 power-conference teams are added here once you approve this format.
 */
export const SCHEDULES: Record<string, TeamSchedule> = {
  [BOSTON_COLLEGE.teamKey]: BOSTON_COLLEGE,
};
