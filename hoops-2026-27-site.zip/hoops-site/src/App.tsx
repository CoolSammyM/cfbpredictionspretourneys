import { useEffect, useState } from 'react';
import StandingsTab from './components/StandingsTab';
import PredictorTab from './components/PredictorTab';
import { loadJson, saveJson } from './lib/storage';

type Tab = 'standings' | 'predictor';
const UI_KEY = 'chs.ui.v1'; // remembers only which tab was open; holds no standings or prediction data

export default function App() {
  const [tab, setTab] = useState<Tab>(() => (loadJson<{ tab: Tab }>(UI_KEY)?.tab === 'predictor' ? 'predictor' : 'standings'));
  useEffect(() => {
    saveJson(UI_KEY, { tab });
  }, [tab]);

  return (
    <div className="app">
      <header className="topbar">
        <div className="topbar-inner">
          <div className="brand">
            <span className="brand-mark">NCAAM</span>
            <span className="brand-title">2026–27 Hoops Tracker</span>
          </div>
          <nav className="tabs" role="tablist" aria-label="Sections">
            <button role="tab" aria-selected={tab === 'standings'} className={tab === 'standings' ? 'tab on' : 'tab'} onClick={() => setTab('standings')}>
              Conference Standings
            </button>
            <button role="tab" aria-selected={tab === 'predictor'} className={tab === 'predictor' ? 'tab on' : 'tab'} onClick={() => setTab('predictor')}>
              Schedule Predictor
            </button>
          </nav>
        </div>
      </header>
      <main className="page">
        {/* Both tabs stay mounted; each owns its own data and its own storage key. */}
        <div hidden={tab !== 'standings'}>
          <StandingsTab />
        </div>
        <div hidden={tab !== 'predictor'}>
          <PredictorTab />
        </div>
      </main>
      <footer className="foot">
        Data is saved in this browser only. Team logos are loaded from ESPN by team id. Unverified data is flagged where it appears.
      </footer>
    </div>
  );
}
