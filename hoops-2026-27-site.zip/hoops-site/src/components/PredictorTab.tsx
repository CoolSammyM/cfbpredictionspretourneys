import { useEffect, useMemo, useState } from 'react';
import type { Game, Pick, PredictorState } from '../types';
import { POWER_CONFERENCES } from '../data/conferences';
import { SCHEDULES } from '../data/schedules';
import {
  cleanPicks, dateParts, emptyPredictorState, fmtRec, groupByMonth, isFinal, resetTeamPicks, setPick, summarize,
} from '../lib/predictor';
import { loadJson, PREDICTOR_KEY, saveJson } from '../lib/storage';
import TeamLogo from './TeamLogo';

const UI_KEY = 'chs.predictor-ui.v1';

function loadState(): PredictorState {
  const saved = loadJson<PredictorState>(PREDICTOR_KEY);
  return saved && saved.version === 1 ? cleanPicks(saved, SCHEDULES) : emptyPredictorState();
}

export default function PredictorTab() {
  const [state, setState] = useState<PredictorState>(loadState);
  const [confId, setConfId] = useState<string>(() => loadJson<{ conf: string }>(UI_KEY)?.conf ?? 'acc');
  const [teamKey, setTeamKey] = useState<string>(() => loadJson<{ team: string }>(UI_KEY)?.team ?? 'boston-college-eagles');
  const [saveFailed, setSaveFailed] = useState(false);

  const conf = POWER_CONFERENCES.find((c) => c.id === confId) ?? POWER_CONFERENCES[0];
  const team = conf.teams.find((t) => t.key === teamKey) ?? conf.teams[0];
  const schedule = SCHEDULES[team.key];
  const confKeys = useMemo(() => new Set(conf.teams.map((t) => t.key)), [conf]);
  const picks = state.picks[team.key] ?? {};

  useEffect(() => {
    setSaveFailed(!saveJson(PREDICTOR_KEY, state));
  }, [state]);
  useEffect(() => {
    saveJson(UI_KEY, { conf: conf.id, team: team.key });
  }, [conf.id, team.key]);

  const summary = useMemo(() => (schedule ? summarize(schedule, picks, confKeys) : null), [schedule, picks, confKeys]);
  const pickCount = Object.keys(picks).length;

  const changeConf = (id: string) => {
    const c = POWER_CONFERENCES.find((x) => x.id === id)!;
    setConfId(id);
    // jump to a team that has a schedule loaded if there is one, otherwise the first team
    setTeamKey((c.teams.find((t) => SCHEDULES[t.key]) ?? c.teams[0]).key);
  };

  const choose = (g: Game, p: Pick) => {
    if (!schedule) return;
    const next = picks[g.id] === p ? null : p; // tapping the selected button clears it
    setState((s) => setPick(s, schedule, g.id, next));
  };

  return (
    <section aria-labelledby="pr-h">
      <div className="page-head">
        <div>
          <h1 id="pr-h">Schedule Predictor</h1>
          <p className="sub">Power six only. Pick every remaining game. Completed results are locked. Separate from your standings.</p>
        </div>
      </div>

      <div className="selectors">
        <select aria-label="Conference" value={conf.id} onChange={(e) => changeConf(e.target.value)}>
          {POWER_CONFERENCES.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
        <div className="team-select">
          <TeamLogo teamKey={team.key} espnId={team.espnId} name={team.name} size={22} />
          <select aria-label="Team" value={team.key} onChange={(e) => setTeamKey(e.target.value)}>
            {conf.teams.map((t) => (
              <option key={t.key} value={t.key}>
                {t.name}
                {SCHEDULES[t.key] ? '' : ' (schedule not loaded)'}
              </option>
            ))}
          </select>
        </div>
      </div>

      {saveFailed && (
        <div className="banner banner-warn">Your browser blocked saving, so picks will be lost on refresh.</div>
      )}

      {!schedule && (
        <div className="banner banner-info">
          <strong>{team.name}: schedule not loaded yet.</strong> Boston College is the first team so you can check the layout and
          format. Once you approve it, every other power-conference team gets a file in exactly the same format. Nothing is
          invented in the meantime.
        </div>
      )}

      {schedule && summary && (
        <>
          <div className="team-card">
            <div className="team-card-id">
              <TeamLogo teamKey={team.key} espnId={team.espnId} name={team.name} size={64} />
              <div>
                <div className="eyebrow">
                  {conf.name} · {schedule.season}
                </div>
                <h2>{team.name}</h2>
                <div className="muted small">
                  Actual {fmtRec(summary.actualOverall)} overall · {fmtRec(summary.actualConf)} {conf.name}
                </div>
              </div>
            </div>
            <div className="stats">
              <Stat label="Proj. overall" value={fmtRec(summary.projOverall)} dark />
              <Stat label={`Proj. ${conf.name}`} value={fmtRec(summary.projConf)} dark />
              <Stat label="Home" value={fmtRec(summary.projHome)} />
              <Stat label="Away" value={fmtRec(summary.projAway)} />
              <Stat label="Remaining" value={String(summary.remaining)} />
              <Stat label="Unpicked" value={String(summary.unpicked)} accent={summary.unpicked > 0} />
            </div>
            <div className="team-card-foot">
              <span>Projected = actual results + your picks. Home/Away split includes picks. Neutral-site games count toward overall only.</span>
              <button
                className="link"
                disabled={pickCount === 0}
                onClick={() => setState((s) => resetTeamPicks(s, team.key))}
              >
                ↺ Reset {pickCount} pick{pickCount === 1 ? '' : 's'}
              </button>
            </div>
          </div>

          <div className={`banner ${schedule.complete ? 'banner-info' : 'banner-warn'}`}>
            <strong>{schedule.complete ? 'Schedule marked complete.' : 'Schedule not fully verified.'}</strong> Source: {schedule.source}.
            <ul>
              {schedule.notes.map((n, i) => (
                <li key={i}>{n}</li>
              ))}
            </ul>
          </div>

          {groupByMonth(schedule.games).map((m) => (
            <div key={m.label} className="month">
              <h3 className="month-h">{m.label}</h3>
              <div className="table-wrap">
                <table className="sched">
                  <thead>
                    <tr>
                      <th className="left">DATE</th>
                      <th className="left">OPPONENT</th>
                      <th>LOCATION</th>
                      <th className="left">RESULT</th>
                      <th>PICK</th>
                    </tr>
                  </thead>
                  <tbody>
                    {m.games.map((g) => (
                      <GameRow key={g.id} game={g} pick={picks[g.id] ?? null} onPick={(p) => choose(g, p)} />
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </>
      )}
    </section>
  );
}

function Stat({ label, value, dark, accent }: { label: string; value: string; dark?: boolean; accent?: boolean }) {
  return (
    <div className={`stat ${dark ? 'stat-dark' : ''}`}>
      <div className="stat-label">{label}</div>
      <div className={`stat-value ${accent ? 'accent' : ''}`}>{value}</div>
    </div>
  );
}

function GameRow({ game: g, pick, onPick }: { game: Game; pick: Pick | null; onPick: (p: Pick) => void }) {
  const d = dateParts(g.date);
  const final = isFinal(g);
  const won = final && g.result!.us > g.result!.them;
  return (
    <tr className={final ? 'final' : ''}>
      <td className="date">
        <div>{d.short}</div>
        <div className="muted mono small">{g.time ?? 'Time TBA'}</div>
      </td>
      <td>
        <div className="opp">
          <span className="vs">{g.site === 'away' ? 'at' : 'vs'}</span>
          <TeamLogo teamKey={g.opp.key} espnId={g.opp.espnId} name={g.opp.name} size={26} />
          <div>
            <div className="opp-name">{g.opp.name}</div>
            <div className="muted small">
              {g.venue ?? 'Venue not listed'}
              {g.event ? ` · ${g.event}` : ''}
            </div>
          </div>
        </div>
      </td>
      <td className="center">
        <span className={`site site-${g.site}`}>{g.site.toUpperCase()}</span>
      </td>
      <td className="result">
        {final ? (
          <span>
            <strong className={won ? 'win' : 'loss'}>{won ? 'W' : 'L'}</strong>{' '}
            <span className="mono">
              {g.result!.us}-{g.result!.them}
            </span>{' '}
            <span className="muted mono small">FINAL</span>
          </span>
        ) : (
          <span className="muted small">
            {g.time ? `Tip ${g.time} ET` : 'Tip time not announced'}
            {g.flags?.length ? ` · ${g.flags.join(', ')}` : ''}
          </span>
        )}
      </td>
      <td className="pick">
        {final ? (
          <span className="locked">ACTUAL · LOCKED</span>
        ) : (
          <span className="pick-btns" role="group" aria-label={`Pick for ${g.opp.name}`}>
            <button
              className={pick === 'W' ? 'pbtn w on' : 'pbtn w'}
              aria-pressed={pick === 'W'}
              onClick={() => onPick('W')}
              title={pick === 'W' ? 'Click again to clear' : 'Pick a win'}
            >
              W
            </button>
            <button
              className={pick === 'L' ? 'pbtn l on' : 'pbtn l'}
              aria-pressed={pick === 'L'}
              onClick={() => onPick('L')}
              title={pick === 'L' ? 'Click again to clear' : 'Pick a loss'}
            >
              L
            </button>
          </span>
        )}
      </td>
    </tr>
  );
}
