import assert from 'node:assert/strict';
import { renderToString } from 'react-dom/server';
import App from '../src/App';

// Server-side render of the whole app (no browser needed). Confirms both tabs mount and show the
// structure the spec asks for. Browser-only behaviour (drag/drop, localStorage) is covered by the logic tests.
const html = renderToString(<App />).replace(/<!-- -->/g, ''); // React inserts these between adjacent text nodes
let passed = 0;
const ok = (name: string, cond: boolean) => {
  assert.ok(cond, name);
  passed++;
  console.log(`  ok  ${name}`);
};

console.log('Render smoke test');
ok('both tabs exist', html.includes('Conference Standings') && html.includes('Schedule Predictor'));
ok('standings: ACC teams from the CSV render in order', html.indexOf('Boston College Eagles') < html.indexOf('California Golden Bears') && html.includes('Wake Forest Demon Deacons'));
ok('standings: column groups', ['CONFERENCE', 'OVERALL', 'POLLS', '>GB<', '>HOME<', '>AWAY<'].every((s) => html.includes(s)));
ok('standings: USA poll column is gone', !html.includes('>USA<') && !html.includes('USA TODAY'));
ok('standings: AP is a dropdown with 25 ranks per team', (html.match(/aria-label="AP rank for Duke"/g) ?? []).length === 1 && html.includes('<option value="25"'));
ok('standings: 32 conferences in the filter', CONF_OPTIONS(html) >= 32);
ok('standings: auto-sort option present', html.includes('Auto-sort by conference PCT'));
ok('predictor: only the six power conferences', ['ACC', 'Big Ten', 'Big 12', 'Big East', 'Pac-12', 'SEC'].every((c) => html.includes(`>${c}</option>`)));
ok('predictor: BC header numbers', html.includes('Actual 6-0 overall') && html.includes('>Remaining<') && html.includes('>Unpicked<'));
ok('predictor: completed games are locked, upcoming have W/L', (html.match(/ACTUAL · LOCKED/g) ?? []).length === 6 && (html.match(/aria-label="Pick for /g) ?? []).length === 26);
ok('predictor: month groups', ['November 2026', 'December 2026', 'January 2027', 'February 2027', 'March 2027'].every((m) => html.includes(m)));
ok('predictor: incompleteness is stated', html.includes('Schedule not fully verified'));

function CONF_OPTIONS(h: string) {
  const m = h.match(/aria-label="Conference filter".*?<\/select>/s);
  return m ? (m[0].match(/<option/g) ?? []).length - 1 : 0; // minus "All conferences"
}

console.log(`\n${passed} render checks passed`);
