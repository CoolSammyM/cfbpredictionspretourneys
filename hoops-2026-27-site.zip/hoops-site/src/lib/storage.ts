// Two completely separate persistence keys. Neither module reads or writes the other's key.
export const STANDINGS_KEY = 'chs.standings.v1';
export const PREDICTOR_KEY = 'chs.predictor.v1';

export function loadJson<T>(key: string): T | null {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null; // storage blocked or corrupt JSON: fall back to defaults
  }
}

/** Returns false when the browser refused the write (private mode, quota, blocked storage). */
export function saveJson(key: string, value: unknown): boolean {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

export function removeKey(key: string) {
  try {
    window.localStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}
