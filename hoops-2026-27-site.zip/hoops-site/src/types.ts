// ---------- Shared / data ----------
export type Verification = 'csv' | 'sourced' | 'screenshot' | 'unverified';

export interface Team {
  key: string; // stable slug, e.g. "boston-college-eagles"
  name: string; // display name
  short: string; // short school name used in labels like "8 - Duke"
  espnId: number | null; // ESPN team id used for logos (null = not yet resolved)
}

export interface Conference {
  id: string;
  name: string;
  maxConfGames: number;
  power: boolean; // one of the six Schedule Predictor conferences
  verification: Verification;
  note?: string;
  teams: Team[]; // default order (ACC = pickem-standings-acc.csv order)
}

// ---------- Conference Standings tab (own data model + own storage key) ----------
export interface TeamRecord {
  confW: number | null;
  confL: number | null;
  ovW: number | null;
  ovL: number | null;
  homeW: number | null;
  homeL: number | null;
  awayW: number | null;
  awayL: number | null;
  ap: number | null; // 1-25 or null (unranked); each rank may belong to one team only
}

export interface StandingsState {
  version: 1;
  autoSort: boolean;
  order: Record<string, string[]>; // conferenceId -> ordered team keys
  records: Record<string, TeamRecord>; // teamKey -> record
}

// ---------- Schedule Predictor tab (own data model + own storage key) ----------
export type Site = 'home' | 'away' | 'neutral';
export type Pick = 'W' | 'L';

export interface Game {
  id: string;
  date: string; // YYYY-MM-DD
  time: string | null; // "7:00 PM" (ET) or null when not announced
  opp: { key: string | null; name: string; espnId: number | null };
  site: Site;
  venue: string | null;
  result?: { us: number; them: number }; // present only for completed games (locked)
  event?: string; // tournament / challenge label
  flags?: string[]; // per-game verification notes
}

export interface TeamSchedule {
  teamKey: string;
  season: string;
  source: string;
  retrieved: string;
  complete: boolean;
  notes: string[];
  games: Game[];
}

export interface PredictorState {
  version: 1;
  picks: Record<string, Record<string, Pick>>; // teamKey -> gameId -> pick
}
