import type { Game, Pick, PredictorState, TeamSchedule } from '../types';

export interface Rec {
  w: number;
  l: number;
}

export interface Summary {
  actualOverall: Rec;
  projOverall: Rec;
  actualConf: Rec;
  projConf: Rec;
  projHome: Rec;
  projAway: Rec;
  remaining: number;
  unpicked: number;
}

export const isFinal = (g: Game) => !!g.result;
export const outcome = (g: Game): Pick | null => (g.result ? (g.result.us > g.result.them ? 'W' : 'L') : null);

/**
 * Projected = completed results + the user's picks.
 * - Unpicked games count as neither a win nor a loss.
 * - Neutral-site games count toward overall (and conference if the opponent is a conference member)
 *   but never toward home or away.
 * - Only opponents whose team key is in `confKeys` count toward conference records.
 */
export function summarize(schedule: TeamSchedule, picks: Record<string, Pick>, confKeys: Set<string>): Summary {
  const s: Summary = {
    actualOverall: { w: 0, l: 0 }, projOverall: { w: 0, l: 0 },
    actualConf: { w: 0, l: 0 }, projConf: { w: 0, l: 0 },
    projHome: { w: 0, l: 0 }, projAway: { w: 0, l: 0 },
    remaining: 0, unpicked: 0,
  };
  const bump = (r: Rec, p: Pick) => (p === 'W' ? r.w++ : r.l++);
  for (const g of schedule.games) {
    const actual = outcome(g);
    const projected = actual ?? picks[g.id] ?? null;
    const isConf = !!g.opp.key && confKeys.has(g.opp.key);
    if (!actual) {
      s.remaining++;
      if (!picks[g.id]) s.unpicked++;
    }
    if (actual) {
      bump(s.actualOverall, actual);
      if (isConf) bump(s.actualConf, actual);
    }
    if (projected) {
      bump(s.projOverall, projected);
      if (isConf) bump(s.projConf, projected);
      if (g.site === 'home') bump(s.projHome, projected);
      else if (g.site === 'away') bump(s.projAway, projected);
    }
  }
  return s;
}

export const fmtRec = (r: Rec) => `${r.w}-${r.l}`;

export const emptyPredictorState = (): PredictorState => ({ version: 1, picks: {} });

/** Pure update helpers: picks for completed games are never stored. */
export function setPick(state: PredictorState, schedule: TeamSchedule, gameId: string, pick: Pick | null): PredictorState {
  const game = schedule.games.find((g) => g.id === gameId);
  if (!game || isFinal(game)) return state; // locked
  const teamPicks = { ...(state.picks[schedule.teamKey] ?? {}) };
  if (pick === null) delete teamPicks[gameId];
  else teamPicks[gameId] = pick;
  return { ...state, picks: { ...state.picks, [schedule.teamKey]: teamPicks } };
}

export function resetTeamPicks(state: PredictorState, teamKey: string): PredictorState {
  const picks = { ...state.picks };
  delete picks[teamKey];
  return { ...state, picks };
}

/** Drop stored picks for games that no longer exist or have since become final. */
export function cleanPicks(state: PredictorState, schedules: Record<string, TeamSchedule>): PredictorState {
  const picks: PredictorState['picks'] = {};
  for (const [teamKey, tp] of Object.entries(state.picks ?? {})) {
    const sch = schedules[teamKey];
    if (!sch) continue;
    const kept: Record<string, Pick> = {};
    for (const [gid, p] of Object.entries(tp)) {
      const g = sch.games.find((x) => x.id === gid);
      if (g && !isFinal(g) && (p === 'W' || p === 'L')) kept[gid] = p;
    }
    picks[teamKey] = kept;
  }
  return { version: 1, picks };
}

// ---------- dates (timezone-safe: dates are plain calendar dates) ----------
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function dateParts(d: string) {
  const [y, m, day] = d.split('-').map(Number);
  const dow = new Date(Date.UTC(y, m - 1, day)).getUTCDay();
  return { y, m, day, dow, monthName: MONTHS[m - 1], dowName: DOW[dow], short: `${DOW[dow]}, ${MONTHS[m - 1].slice(0, 3)} ${day}` };
}

export function groupByMonth(games: Game[]): { label: string; games: Game[] }[] {
  const sorted = [...games].sort((a, b) => a.date.localeCompare(b.date) || (a.time ?? '').localeCompare(b.time ?? ''));
  const groups: { label: string; games: Game[] }[] = [];
  for (const g of sorted) {
    const { monthName, y } = dateParts(g.date);
    const label = `${monthName} ${y}`;
    const last = groups[groups.length - 1];
    if (last && last.label === label) last.games.push(g);
    else groups.push({ label, games: [g] });
  }
  return groups;
}
