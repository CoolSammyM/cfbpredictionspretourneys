import generated from '../data/espn-ids.generated.json';

type GeneratedMap = Record<string, { id: number; displayName?: string }>;

/**
 * Logo URL is keyed by ESPN team id (never by matching on the team name).
 * Id sources, in order: id written in the data files, then the generated map produced by
 * `npm run resolve-ids` (which matches against ESPN's own team list at build time).
 */
export function espnIdFor(teamKey: string | null, explicit: number | null): number | null {
  if (explicit) return explicit;
  if (!teamKey) return null;
  return (generated as GeneratedMap)[teamKey]?.id ?? null;
}

export const logoUrl = (id: number) => `https://a.espncdn.com/i/teamlogos/ncaa/500/${id}.png`;
