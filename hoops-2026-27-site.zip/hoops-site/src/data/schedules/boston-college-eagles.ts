import type { Game, Site, TeamSchedule } from '../../types';

/**
 * Boston College Eagles 2026-27 — the first Schedule Predictor team.
 *
 * SOURCES
 *  - Games Nov 3-22 incl. results, times and venues: the schedule you supplied (prompt + screenshot).
 *  - Nov 26-27 (ESPN Events Invitational, State Farm Field House): your screenshot; event confirmed by bceagles.com.
 *  - Dec 1 onward: ESPN team schedule page (retrieved Nov 23, 2026), cross-checked for dates and
 *    home/away against the ACC schedule article on bceagles.com (Sept 9, 2026) for all 18 ACC games.
 *  - Opponent arenas for road games are the opponents' home arenas (ESPN did not print venue text).
 *
 * Your full supplied schedule did not arrive with the second upload. If it differs from the rows below
 * for any game after Nov 22, tell me and I'll correct it. Your supplied rows always win over ESPN.
 */

const H = 'Conte Forum';

type O = Game['opp'];
const opp = (name: string, key: string | null, espnId: number | null = null): O => ({ name, key, espnId });

let n = 0;
const g = (
  date: string, time: string | null, o: O, site: Site, venue: string | null,
  extra: Partial<Game> = {},
): Game => ({ id: `bc-${date}-${++n}`, date, time, opp: o, site, venue, ...extra });

const win = (us: number, them: number) => ({ result: { us, them } });

export const BOSTON_COLLEGE: TeamSchedule = {
  teamKey: 'boston-college-eagles',
  season: '2026-27',
  source: 'Your supplied schedule (Nov 3-22), ESPN (Nov 23, 2026), bceagles.com ACC schedule (Sept 9, 2026)',
  retrieved: '2026-11-23',
  complete: false,
  notes: [
    'Nov 3-22 rows (dates, venues, results) are exactly as you supplied them.',
    'Dec 1 onward comes from ESPN. Tip times are ESPN\'s and are not all confirmed on bceagles.com; Stanford (Feb 27) has no announced time.',
    'ESPN does not print venue names; road venues are the opponents\' home arenas and should be treated as unverified until checked on each school\'s site.',
    'ESPN lists the Dec 5 UMass Lowell game with a ticket link labeled as a hockey event. Date and opponent match the ACC Network listing, but double-check the tip time.',
    'A Florida Atlantic home-and-home that was reported to end in 2026-27 does not appear on ESPN\'s list, so it is not included.',
    'The Oct 25 exhibition vs MIT is excluded from season records.',
    'No postseason games are listed yet. The ACC Tournament is March 9-13, 2027 at First Horizon Coliseum in Greensboro; matchups are not set until seeding.',
  ],
  games: [
    // ---- Supplied by you: completed, locked ----
    g('2026-11-03', '7:00 PM', opp('Wagner Seahawks', 'wagner', 2681), 'home', H, win(76, 50)),
    g('2026-11-06', '4:00 PM', opp('Massachusetts Minutemen', 'umass', 113), 'neutral', 'TD Garden', win(71, 55)),
    g('2026-11-10', '7:00 PM', opp('Maryland Eastern Shore Hawks', 'maryland-eastern-shore', 2379), 'home', H, win(82, 54)),
    g('2026-11-15', '1:30 PM', opp('New Hampshire Wildcats', 'new-hampshire-wildcats', 160), 'home', H, win(67, 55)),
    g('2026-11-18', '8:00 PM', opp('Harvard Crimson', 'harvard', 108), 'away', 'Lavietes Pavilion', win(74, 69)),
    g('2026-11-22', '5:00 PM', opp('NJIT Highlanders', 'njit-highlanders', 2885), 'home', H, win(79, 59)),

    // ---- ESPN Events Invitational (neutral) ----
    g('2026-11-26', '1:30 PM', opp('UCF Knights', 'ucf', 2116), 'neutral', 'State Farm Field House', { event: 'ESPN Events Invitational' }),
    g('2026-11-27', '4:30 PM', opp('Cincinnati Bearcats', 'cincinnati', 2132), 'neutral', 'State Farm Field House', { event: 'ESPN Events Invitational' }),

    // ---- Non-conference (ESPN) ----
    g('2026-12-01', '5:00 PM', opp('Georgia Bulldogs', 'georgia', 61), 'away', 'Stegeman Coliseum', { event: 'ACC/SEC Challenge' }),
    g('2026-12-05', '7:00 PM', opp('UMass Lowell River Hawks', 'umass-lowell-river-hawks', 2349), 'home', H),
    g('2026-12-09', '9:00 PM', opp('Northeastern Huskies', 'northeastern', 111), 'home', H),
    g('2026-12-12', '12:00 PM', opp('George Washington Revolutionaries', 'george-washington', 45), 'home', H),
    g('2026-12-20', '12:00 PM', opp('New Haven Chargers', null), 'home', H),
    g('2026-12-22', '7:00 PM', opp('Stonehill Skyhawks', 'stonehill'), 'home', H),

    // ---- ACC (18 games; home/away confirmed against bceagles.com) ----
    g('2027-01-02', '4:00 PM', opp('North Carolina Tar Heels', 'north-carolina-tar-heels', 153), 'home', H),
    g('2027-01-05', '9:00 PM', opp('Clemson Tigers', 'clemson-tigers', 228), 'home', H),
    g('2027-01-09', '8:00 PM', opp('Virginia Tech Hokies', 'virginia-tech-hokies', 259), 'away', 'Cassell Coliseum'),
    g('2027-01-13', '8:00 PM', opp('Virginia Cavaliers', 'virginia-cavaliers', 258), 'away', 'John Paul Jones Arena'),
    g('2027-01-16', '7:00 PM', opp('Duke Blue Devils', 'duke-blue-devils', 150), 'home', H),
    g('2027-01-19', '7:00 PM', opp('Syracuse Orange', 'syracuse-orange', 183), 'away', 'JMA Wireless Dome'),
    g('2027-01-23', '7:00 PM', opp('Pittsburgh Panthers', 'pittsburgh-panthers', 221), 'away', 'Petersen Events Center'),
    g('2027-01-27', '7:00 PM', opp('Louisville Cardinals', 'louisville-cardinals', 97), 'home', H),
    g('2027-02-02', '6:00 PM', opp('Wake Forest Demon Deacons', 'wake-forest-demon-deacons', 154), 'away', 'Lawrence Joel Veterans Memorial Coliseum'),
    g('2027-02-06', '5:30 PM', opp('Notre Dame Fighting Irish', 'notre-dame-fighting-irish', 87), 'home', H),
    g('2027-02-09', '9:00 PM', opp('Georgia Tech Yellow Jackets', 'georgia-tech-yellow-jackets', 59), 'home', H),
    g('2027-02-13', '1:00 PM', opp('NC State Wolfpack', 'nc-state-wolfpack', 152), 'away', 'Lenovo Center'),
    g('2027-02-16', '7:00 PM', opp('SMU Mustangs', 'smu-mustangs', 2567), 'home', H),
    g('2027-02-20', '12:00 PM', opp('Virginia Tech Hokies', 'virginia-tech-hokies', 259), 'home', H),
    g('2027-02-24', '9:00 PM', opp('California Golden Bears', 'california-golden-bears', 25), 'away', 'Haas Pavilion'),
    g('2027-02-27', null, opp('Stanford Cardinal', 'stanford-cardinal', 24), 'away', 'Maples Pavilion', { flags: ['Tip time not announced'] }),
    g('2027-03-03', '6:30 PM', opp('Florida State Seminoles', 'florida-state-seminoles', 52), 'home', H),
    g('2027-03-06', '2:00 PM', opp('Notre Dame Fighting Irish', 'notre-dame-fighting-irish', 87), 'away', 'Purcell Pavilion'),
  ],
};
